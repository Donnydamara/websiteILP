

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Target Desa List')); ?></h1>

    <!-- Main Content goes here -->
    <a href="<?php echo e(route('target-desa.create')); ?>" class="btn btn-primary mb-3">Tambah</a>

    <!-- Display success message if any -->
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered table-striped" id="dataTable">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Provinsi</th>
                    <th>Kota</th>
                    <th>Kecamatan</th>
                    <th>Desa</th>
                    <th>Puskesmas</th>
                    <th>Target Kepala Keluarga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $targetDesas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetDesa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($targetDesa->provinsi); ?></td>
                        <td><?php echo e($targetDesa->kota); ?></td>
                        <td><?php echo e($targetDesa->kecamatan); ?></td>
                        <td><?php echo e($targetDesa->desa); ?></td>
                        <td><?php echo e($targetDesa->puskesmas); ?></td>
                        <td><?php echo e($targetDesa->target_penduduk); ?></td>
                        <td>
                            <div class="d-flex justify-content-center">
                                <a href="<?php echo e(route('target-desa.edit', $targetDesa->id)); ?>"
                                    class="btn btn-sm btn-primary mr-2">Edit</a>


                                <form action="<?php echo e(route('target-desa.destroy', $targetDesa->id)); ?>" method="post"
                                    class="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger delete-button">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php echo e($targetDesas->links()); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/targetdesa/list.blade.php ENDPATH**/ ?>