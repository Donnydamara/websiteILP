

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Tambah Data Kunjungan Rumah Bayi')); ?></h1>

    <!-- Main Content goes here -->

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('kunjungan_rumah_bayi.storevalidate')); ?>" method="post" id="modal-save-form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="status">Status Kunjungan TBC</label>
                    <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" id="status" required>
                        <option value="" disabled <?php echo e(old('status') === null ? 'selected' : ''); ?>>Pilih</option>
                        <option value="Ya" <?php echo e(old('status') === 'Ya' || old('status') === null ? 'selected' : ''); ?>>Ya
                        </option>
                        <option value="Tidak" <?php echo e(old('status') === 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="card" style="text-align: center">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nik">NIK</label>
                                <div class="input-group">
                                    <input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="nik" id="nik" value="<?php echo e(old('nik')); ?>" required>
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" id="btnCekData">Cek
                                            Data</button>
                                    </div>
                                </div>
                                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kk">Kartu Keluarga</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kk"
                                    id="kk" placeholder="kk" value="<?php echo e(old('kk')); ?>" required readonly>
                                <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="nama" id="nama" placeholder="Nama" value="<?php echo e(old('nama')); ?>" required
                                    readonly>
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tgl_lahir">Tanggal Lahir</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_lahir" id="tgl_lahir" value="<?php echo e(old('tgl_lahir')); ?>" required>
                                <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tmp_lahir">Tempat Lahir</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['tmp_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tmp_lahir" id="tmp_lahir" placeholder="Tempat Lahir" autocomplete="off"
                                    value="<?php echo e(old('tmp_lahir')); ?>" required>
                                <?php $__errorArgs = ['tmp_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="gender">Jenis Kelamin</label>
                                <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender"
                                    id="gender" required>
                                    <option value="Laki-laki" <?php echo e(old('gender') == 'Laki-laki' ? 'selected' : ''); ?>>
                                        Laki-laki</option>
                                    <option value="Perempuan" <?php echo e(old('gender') == 'Perempuan' ? 'selected' : ''); ?>>
                                        Perempuan</option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kunjungan">Kunjungan</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kunjungan" id="kunjungan" placeholder="Kunjungan" autocomplete="off"
                                    value="<?php echo e(old('kunjungan')); ?>" required>
                                <?php $__errorArgs = ['kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tgl_kunjungan">Tanggal</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_kunjungan" id="tgl_kunjungan" value="<?php echo e(old('tgl_kunjungan')); ?>" required>
                                <?php $__errorArgs = ['tgl_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="suhu">Suhu</label>
                                <select class="form-control <?php $__errorArgs = ['suhu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="suhu"
                                    id="suhu" required>
                                    <option value="<37,5 C" <?php echo e(old('suhu') == '<37,5 C' ? 'selected' : ''); ?>>
                                        &lt;37,5 C</option>
                                    <option value=">37,5 C" <?php echo e(old('suhu') == '>37,5 C' ? 'selected' : ''); ?>>
                                        &gt;37,5 C</option>
                                </select>
                                <?php $__errorArgs = ['suhu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="suhu">Ada Buku KIA</label>
                                <select class="form-control <?php $__errorArgs = ['buku_kia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="buku_kia"
                                    id="buku_kia" required>
                                    <option value="Ya" <?php echo e(old('buku_kia') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('buku_kia') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['buku_kia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="suhu">ASI Eklusif</label>
                                <select class="form-control <?php $__errorArgs = ['asi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asi"
                                    id="asi" required>
                                    <option value="Ya" <?php echo e(old('asi') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('asi') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['asi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="lila">LILA < 23,4 cm</label>
                                        <select class="form-control <?php $__errorArgs = ['lila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="lila"
                                            id="lila" required>
                                            <option value="">Pilih Opsi</option>
                                            <option value="Ada" <?php echo e(old('lila') == 'Ada' ? 'selected' : ''); ?>>
                                                Ada
                                            </option>
                                            <option value="Tidak" <?php echo e(old('lila') == 'Tidak' ? 'selected' : ''); ?>>
                                                Tidak
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['lila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Tanggal Terakhir Ditimbang Dan Diukur</h5>
                            </div>
                        </div>
                    </div>

                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tgl_timbang">Tanggal</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_timbang" id="tgl_timbang" value="<?php echo e(old('tgl_timbang')); ?>" required>
                                <?php $__errorArgs = ['tgl_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tmp_timbang">Tempat</label>
                                <select class="form-control <?php $__errorArgs = ['tmp_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tmp_timbang" id="tmp_timbang" required>
                                    <option value="Puskesmas/Postu"
                                        <?php echo e(old('tmp_timbang') == 'Puskesmas/Postu' ? 'selected' : ''); ?>>
                                        Puskesmas/Postu</option>
                                    <option value="Ponkesdes/Polindes"
                                        <?php echo e(old('tmp_timbang') == 'Ponkesdes/Polindes' ? 'selected' : ''); ?>>
                                        Ponkesdes/Polindes</option>
                                    <option value="BPM" <?php echo e(old('tmp_timbang') == 'BPM' ? 'selected' : ''); ?>>
                                        BPM</option>
                                    <option value="Posyandu" <?php echo e(old('tmp_timbang') == 'Posyandu' ? 'selected' : ''); ?>>
                                        Posyandu</option>
                                    <option value="Rumah" <?php echo e(old('tmp_timbang') == 'Rumah' ? 'selected' : ''); ?>>
                                        Rumah</option>
                                </select>
                                <?php $__errorArgs = ['tmp_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="petugas_timbang">Petugas</label>
                                <select class="form-control <?php $__errorArgs = ['petugas_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="petugas_timbang" id="petugas_timbang" required>
                                    <option value="Bidan" <?php echo e(old('petugas_timbang') == 'Bidan' ? 'selected' : ''); ?>>
                                        Bidan</option>
                                    <option value="Perawat" <?php echo e(old('petugas_timbang') == 'Perawat' ? 'selected' : ''); ?>>
                                        Perawat</option>
                                    <option value="Kader" <?php echo e(old('petugas_timbang') == 'Kader' ? 'selected' : ''); ?>>
                                        Kader</option>
                                </select>
                                <?php $__errorArgs = ['petugas_timbang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Hasil Penimbangan Dan Pengukuran</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="hasil_timbang_ukur_bb">BB</label>
                                <input type="number"
                                    class="form-control <?php $__errorArgs = ['hasil_timbang_ukur_bb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="hasil_timbang_ukur_bb" id="hasil_timbang_ukur_bb" placeholder="BB"
                                    autocomplete="off" value="<?php echo e(old('hasil_timbang_ukur_bb')); ?>" required>
                                <?php $__errorArgs = ['hasil_timbang_ukur_bb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="hasil_timbang_ukur_pb">PB</label>
                                <input type="number"
                                    class="form-control <?php $__errorArgs = ['hasil_timbang_ukur_pb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="hasil_timbang_ukur_pb" id="hasil_timbang_ukur_pb" placeholder="PB"
                                    autocomplete="off" value="<?php echo e(old('hasil_timbang_ukur_pb')); ?>" required>
                                <?php $__errorArgs = ['hasil_timbang_ukur_pb'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="hasil_timbang_ukur_lk">LK</label>
                                <input type="number"
                                    class="form-control <?php $__errorArgs = ['hasil_timbang_ukur_lk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="hasil_timbang_ukur_lk" id="hasil_timbang_ukur_lk" placeholder="LK"
                                    autocomplete="off" value="<?php echo e(old('hasil_timbang_ukur_lk')); ?>" required>
                                <?php $__errorArgs = ['hasil_timbang_ukur_lk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Kunjungan Pemeriksaan Setelah Dilahirkan (0-28 Hari)</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="jenis_kunjungan_pemeriksaan">Jenis Kunjungan/Pemeriksaan</label>
                                <select class="form-control <?php $__errorArgs = ['jenis_kunjungan_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jenis_kunjungan_pemeriksaan" id="jenis_kunjungan_pemeriksaan" required>
                                    <option value="Pelayanan Esensial (0-6 Jam)"
                                        <?php echo e(old('jenis_kunjungan_pemeriksaan') == 'Pelayanan Esensial (0-6 Jam)' ? 'selected' : ''); ?>>
                                        Pelayanan Esensial (0-6 Jam)</option>
                                    <option value="KN 1 (6-48 Jam)"
                                        <?php echo e(old('jenis_kunjungan_pemeriksaan') == 'KN 1 (6-48 Jam)' ? 'selected' : ''); ?>>
                                        KN 1 (6-48 Jam)</option>
                                    <option value="KN 2 (3-7 Hari)"
                                        <?php echo e(old('jenis_kunjungan_pemeriksaan') == 'KN 2 (3-7 Hari)' ? 'selected' : ''); ?>>
                                        KN 2 (3-7 Hari)</option>
                                    <option value="KN 3 (8 - 28 Hari)"
                                        <?php echo e(old('jenis_kunjungan_pemeriksaan') == 'KN 3 (8 - 28 Hari)' ? 'selected' : ''); ?>>
                                        KN 3 (8 - 28 Hari)</option>
                                </select>
                                <?php $__errorArgs = ['jenis_kunjungan_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin: 1%">

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tgl_pemeriksaan">Tanggal</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_pemeriksaan" id="tgl_pemeriksaan" value="<?php echo e(old('tgl_pemeriksaan')); ?>"
                                    required>
                                <?php $__errorArgs = ['tgl_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tmp_pemeriksaan">Tempat</label>
                                <select class="form-control <?php $__errorArgs = ['tmp_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tmp_pemeriksaan" id="tmp_pemeriksaan" required>
                                    <option value="" disabled selected>Pilih Tempat Pemeriksaan</option>
                                    <option value="Puskesmas/Puskesmas Pembantu"
                                        <?php echo e(old('tmp_pemeriksaan') == 'Puskesmas/Puskesmas Pembantu' ? 'selected' : ''); ?>>
                                        Puskesmas/Puskesmas Pembantu</option>
                                    <option value="Rumah Sakit"
                                        <?php echo e(old('tmp_pemeriksaan') == 'Rumah Sakit' ? 'selected' : ''); ?>>Rumah Sakit
                                    </option>
                                    <option value="Ponkesdes/Polindes"
                                        <?php echo e(old('tmp_pemeriksaan') == 'Ponkesdes/Polindes' ? 'selected' : ''); ?>>
                                        Ponkesdes/Polindes</option>
                                    <option value="BPM" <?php echo e(old('tmp_pemeriksaan') == 'BPM' ? 'selected' : ''); ?>>BPM
                                    </option>
                                </select>
                                <?php $__errorArgs = ['tmp_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="petugas_pemeriksaan">Petugas</label>
                                <select class="form-control <?php $__errorArgs = ['petugas_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="petugas_pemeriksaan" id="petugas_pemeriksaan" required>
                                    <option value="" disabled selected>Pilih Petugas Pemeriksaan</option>
                                    <option value="Dokter" <?php echo e(old('petugas_pemeriksaan') == 'Dokter' ? 'selected' : ''); ?>>
                                        Dokter</option>
                                    <option value="Bidan" <?php echo e(old('petugas_pemeriksaan') == 'Bidan' ? 'selected' : ''); ?>>
                                        Bidan</option>
                                    <option value="Perawat"
                                        <?php echo e(old('petugas_pemeriksaan') == 'Perawat' ? 'selected' : ''); ?>>Perawat</option>
                                    <option value="Kader" <?php echo e(old('petugas_pemeriksaan') == 'Kader' ? 'selected' : ''); ?>>
                                        Kader</option>
                                </select>
                                <?php $__errorArgs = ['petugas_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Jenis Imunisasi</h5>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card" style="margin: 2%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Imunisasi 0 Bulan</h5>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="hepatitis_b_0bln">Hepatitis B (<24 Jam)</label>
                                            <input type="date"
                                                class="form-control <?php $__errorArgs = ['hepatitis_b_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="hepatitis_b_0bln" id="hepatitis_b_0bln"
                                                value="<?php echo e(old('hepatitis_b_0bln')); ?>">
                                            <?php $__errorArgs = ['hepatitis_b_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="bcg_0bln">BCG </label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['bcg_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="bcg_0bln" id="bcg_0bln" value="<?php echo e(old('bcg_0bln')); ?>">
                                    <?php $__errorArgs = ['bcg_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="polio_tetes_0bln">Polio Tetes 1</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['polio_tetes_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="polio_tetes_0bln" id="polio_tetes_0bln"
                                        value="<?php echo e(old('polio_tetes_0bln')); ?>">
                                    <?php $__errorArgs = ['polio_tetes_0bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin: 2%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Imunisasi 1 Bulan</h5>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="bcg_1bln">BCG </label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['bcg_1bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="bcg_1bln" id="bcg_1bln" value="<?php echo e(old('bcg_1bln')); ?>">
                                    <?php $__errorArgs = ['bcg_1bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="polio_tetes_1_1bln">Polio Tetes 1</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['polio_tetes_1_1bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="polio_tetes_1_1bln" id="polio_tetes_1_1bln"
                                        value="<?php echo e(old('polio_tetes_1_1bln')); ?>">
                                    <?php $__errorArgs = ['polio_tetes_1_1bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin: 2%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Imunisasi 2 Bulan</h5>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="dpt_hb_hib_1_2bln">DPT HB Hib 1</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['dpt_hb_hib_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="dpt_hb_hib_1_2bln" id="dpt_hb_hib_1_2bln"
                                        value="<?php echo e(old('dpt_hb_hib_1_2bln')); ?>">
                                    <?php $__errorArgs = ['dpt_hb_hib_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="polio_tetes_1_2bln">Polio Tetes 2</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['polio_tetes_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="polio_tetes_1_2bln" id="polio_tetes_1_2bln"
                                        value="<?php echo e(old('polio_tetes_1_2bln')); ?>">
                                    <?php $__errorArgs = ['polio_tetes_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="pcv_1_2bln">PCV 1</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['pcv_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="pcv_1_2bln" id="pcv_1_2bln" value="<?php echo e(old('pcv_1_2bln')); ?>">
                                    <?php $__errorArgs = ['pcv_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="rv_1_2bln">RV 1</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['rv_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="rv_1_2bln" id="rv_1_2bln" value="<?php echo e(old('rv_1_2bln')); ?>">
                                    <?php $__errorArgs = ['rv_1_2bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin: 2%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Imunisasi 3 Bulan</h5>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="dpt_hb_hib_2_3bln">DPT HB Hib 2</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['dpt_hb_hib_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="dpt_hb_hib_2_3bln" id="dpt_hb_hib_2_3bln"
                                        value="<?php echo e(old('dpt_hb_hib_2_3bln')); ?>">
                                    <?php $__errorArgs = ['dpt_hb_hib_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="polio_tetes_2_3bln">Polio Tetes 3</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['polio_tetes_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="polio_tetes_2_3bln" id="polio_tetes_2_3bln"
                                        value="<?php echo e(old('polio_tetes_2_3bln')); ?>">
                                    <?php $__errorArgs = ['polio_tetes_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="pcv_2_3bln">PCV 2</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['pcv_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="pcv_2_3bln" id="pcv_2_3bln" value="<?php echo e(old('pcv_2_3bln')); ?>">
                                    <?php $__errorArgs = ['pcv_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="rv_2_3bln">RV 2</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['rv_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="rv_2_3bln" id="rv_2_3bln" value="<?php echo e(old('rv_2_3bln')); ?>">
                                    <?php $__errorArgs = ['rv_2_3bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin: 2%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Imunisasi 4 Bulan</h5>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="dpt_hb_hib_3_4bln">DPT HB Hib 3</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['dpt_hb_hib_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="dpt_hb_hib_3_4bln" id="dpt_hb_hib_3_4bln"
                                        value="<?php echo e(old('dpt_hb_hib_3_4bln')); ?>">
                                    <?php $__errorArgs = ['dpt_hb_hib_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="polio_tetes_3_4bln">Polio Tetes 4</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['polio_tetes_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="polio_tetes_3_4bln" id="polio_tetes_3_4bln"
                                        value="<?php echo e(old('polio_tetes_3_4bln')); ?>">
                                    <?php $__errorArgs = ['polio_tetes_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="pcv_3_4bln">PCV 3</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['pcv_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="pcv_3_4bln" id="pcv_3_4bln" value="<?php echo e(old('pcv_3_4bln')); ?>">
                                    <?php $__errorArgs = ['pcv_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="rv_3_4bln">RV 3</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['rv_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="rv_3_4bln" id="rv_3_4bln" value="<?php echo e(old('rv_3_4bln')); ?>">
                                    <?php $__errorArgs = ['rv_3_4bln'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Pemberian Edukasi / Kunjungan Nakes</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <input type="text"
                                    class="form-control <?php $__errorArgs = ['edukasi_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="edukasi_kunjungan" id="edukasi_kunjungan" placeholder="Edukasi Kunjungan"
                                    autocomplete="off" value="<?php echo e(old('edukasi_kunjungan')); ?>" required>
                                <?php $__errorArgs = ['edukasi_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group">
                                <h5>Tanda Bahaya Pada Bayi 0-2 Bulan</h5>
                            </div>
                        </div>
                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="napas">Napas</label>
                                <select class="form-control <?php $__errorArgs = ['napas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="napas"
                                    id="napas" required>
                                    <option value="Ya" <?php echo e(old('napas') == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e(old('napas') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['napas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="aktifitas">Aktifitas</label>
                                <select class="form-control <?php $__errorArgs = ['aktifitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="aktifitas"
                                    id="aktifitas" required>
                                    <option value="Ya" <?php echo e(old('aktifitas') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('aktifitas') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['aktifitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="warna_kulit">Warna Kulit</label>
                                <select class="form-control <?php $__errorArgs = ['warna_kulit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="warna_kulit" id="warna_kulit" required>
                                    <option value="Ya" <?php echo e(old('warna_kulit') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('warna_kulit') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['warna_kulit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="hisapan_bayi">Hisapan Bayi</label>
                                <select class="form-control <?php $__errorArgs = ['hisapan_bayi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="hisapan_bayi" id="hisapan_bayi" required>
                                    <option value="Ya" <?php echo e(old('hisapan_bayi') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('hisapan_bayi') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['hisapan_bayi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kejang">Kejang</label>
                                <select class="form-control <?php $__errorArgs = ['kejang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kejang"
                                    id="kejang" required>
                                    <option value="Ya" <?php echo e(old('kejang') == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e(old('kejang') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['kejang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="suhu_tubuh">Suhu Tubuh</label>
                                <select class="form-control <?php $__errorArgs = ['suhu_tubuh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="suhu_tubuh"
                                    id="suhu_tubuh" required>
                                    <option value="<37,5 C" <?php echo e(old('suhu_tubuh') == '<37,5 C' ? 'selected' : ''); ?>>
                                        <37,5 C</option>
                                    <option value=">37,5 C" <?php echo e(old('suhu_tubuh') == '>37,5 C' ? 'selected' : ''); ?>>
                                        >37,5 C</option>
                                </select>
                                <?php $__errorArgs = ['suhu_tubuh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="bab">Buang Air Besar (BAB)</label>
                                <select class="form-control <?php $__errorArgs = ['bab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bab"
                                    id="bab" required>
                                    <option value="Ya" <?php echo e(old('bab') == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e(old('bab') == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['bab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jmhdanwarna_kencing">Jumlah dan Warna Kencing</label>
                                <select class="form-control <?php $__errorArgs = ['jmhdanwarna_kencing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jmhdanwarna_kencing" id="jmhdanwarna_kencing" required>
                                    <option value="Ya" <?php echo e(old('jmhdanwarna_kencing') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('jmhdanwarna_kencing') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['jmhdanwarna_kencing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="tali_pusar">Tali Pusar</label>
                                <select class="form-control <?php $__errorArgs = ['tali_pusar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tali_pusar"
                                    id="tali_pusar" required>
                                    <option value="Ya" <?php echo e(old('tali_pusar') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('tali_pusar') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['tali_pusar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="mata">Mata</label>
                                <select class="form-control <?php $__errorArgs = ['mata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="mata"
                                    id="mata" required>
                                    <option value="Ya" <?php echo e(old('mata') == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e(old('mata') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['mata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kulit">Kulit</label>
                                <select class="form-control <?php $__errorArgs = ['kulit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kulit"
                                    id="kulit" required>
                                    <option value="Ya" <?php echo e(old('kulit') == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e(old('kulit') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['kulit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="imunisasi">Imunisasi</label>
                                <select class="form-control <?php $__errorArgs = ['imunisasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="imunisasi"
                                    id="imunisasi" required>
                                    <option value="Ya" <?php echo e(old('imunisasi') == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak" <?php echo e(old('imunisasi') == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak</option>
                                </select>
                                <?php $__errorArgs = ['imunisasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="card" style="margin-top: 2%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="pengingat_pemeriksaan">Pengingat Pemeriksaan</label>
                                <input type="text"
                                    class="form-control <?php $__errorArgs = ['pengingat_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="pengingat_pemeriksaan" id="pengingat_pemeriksaan"
                                    placeholder="Pengingat Pemeriksaan" autocomplete="off"
                                    value="<?php echo e(old('pengingat_pemeriksaan')); ?>" required>
                                <?php $__errorArgs = ['pengingat_pemeriksaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="tgl_lapor_nakes">Tanggal Lapor Nakes</label>
                                <input type="date" class="form-control <?php $__errorArgs = ['tgl_lapor_nakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="tgl_lapor_nakes" id="tgl_lapor_nakes" value="<?php echo e(old('tgl_lapor_nakes')); ?>"
                                    required>
                                <?php $__errorArgs = ['tgl_lapor_nakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>


                    <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                    <a href="<?php echo e(route('ibu_hamil.index')); ?>" class="btn btn-default">Kembali Ke List</a>


            </form>
        </div>
    </div>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var statusSelect = document.getElementById('status');
            var fields = {
                'btnCekData': document.getElementById('btnCekData'),
                'kk': document.getElementById('kk'),
                'nik': document.getElementById('nik'),
                'nama': document.getElementById('nama'),
                'tgl_lahir': document.getElementById('tgl_lahir'),
                'tmp_lahir': document.getElementById('tmp_lahir'),
                'gender': document.getElementById('gender'),
                'kunjungan': document.getElementById('kunjungan'),
                'tgl_kunjungan': document.getElementById('tgl_kunjungan'),
                'suhu': document.getElementById('suhu'),
                'buku_kia': document.getElementById('buku_kia'),
                'asi': document.getElementById('asi'),
                'tgl_timbang': document.getElementById('tgl_timbang'),
                'tmp_timbang': document.getElementById('tmp_timbang'),
                'petugas_timbang': document.getElementById('petugas_timbang'),
                'hasil_timbang_ukur_bb': document.getElementById('hasil_timbang_ukur_bb'),
                'hasil_timbang_ukur_pb': document.getElementById('hasil_timbang_ukur_pb'),
                'hasil_timbang_ukur_lk': document.getElementById('hasil_timbang_ukur_lk'),
                'jenis_kunjungan_pemeriksaan': document.getElementById('jenis_kunjungan_pemeriksaan'),
                'tgl_pemeriksaan': document.getElementById('tgl_pemeriksaan'),
                'tmp_pemeriksaan': document.getElementById('tmp_pemeriksaan'),
                'petugas_pemeriksaan': document.getElementById('petugas_pemeriksaan'),
                // 'jenis_imunisasi': document.getElementById('jenis_imunisasi'),
                'hepatitis_b_0bln': document.getElementById('hepatitis_b_0bln'),
                'bcg_0bln': document.getElementById('bcg_0bln'),
                'polio_tetes_0bln': document.getElementById('polio_tetes_0bln'),
                'bcg_1bln': document.getElementById('bcg_1bln'),
                'polio_tetes_1_1bln': document.getElementById('polio_tetes_1_1bln'),
                'dpt_hb_hib_1_2bln': document.getElementById('dpt_hb_hib_1_2bln'),
                'polio_tetes_1_2bln': document.getElementById('polio_tetes_1_2bln'),
                'pcv_1_2bln': document.getElementById('pcv_1_2bln'),
                'rv_1_2bln': document.getElementById('rv_1_2bln'),
                'dpt_hb_hib_2_3bln': document.getElementById('dpt_hb_hib_2_3bln'),
                'polio_tetes_2_3bln': document.getElementById('polio_tetes_2_3bln'),
                'pcv_2_3bln': document.getElementById('pcv_2_3bln'),
                'rv_2_3bln': document.getElementById('rv_2_3bln'),
                'dpt_hb_hib_3_4bln': document.getElementById('dpt_hb_hib_3_4bln'),
                'polio_tetes_3_4bln': document.getElementById('polio_tetes_3_4bln'),
                'pcv_3_4bln': document.getElementById('pcv_3_4bln'),
                'rv_3_4bln': document.getElementById('rv_3_4bln'),
                'edukasi_kunjungan': document.getElementById('edukasi_kunjungan'),
                'napas': document.getElementById('napas'),
                'aktifitas': document.getElementById('aktifitas'),
                'warna_kulit': document.getElementById('warna_kulit'),
                'hisapan_bayi': document.getElementById('hisapan_bayi'),
                'kejang': document.getElementById('kejang'),
                'suhu_tubuh': document.getElementById('suhu_tubuh'),
                'bab': document.getElementById('bab'),
                'jmhdanwarna_kencing': document.getElementById('jmhdanwarna_kencing'),
                'tali_pusar': document.getElementById('tali_pusar'),
                'mata': document.getElementById('mata'),
                'kulit': document.getElementById('kulit'),
                'imunisasi': document.getElementById('imunisasi'),
                'pengingat_pemeriksaan': document.getElementById('pengingat_pemeriksaan'),
                'tgl_lapor_nakes': document.getElementById('tgl_lapor_nakes')
            };


            // Memeriksa jika ada data tersimpan di local storage
            for (var key in fields) {
                var storedValue = localStorage.getItem(key);
                if (storedValue !== null) {
                    fields[key].value = storedValue;
                }
            }

            // Set nilai dropdown "Status Ibu Bersalin Nifas" menggunakan old value jika ada
            var oldStatusValue = "<?php echo e(old('status')); ?>";
            if (oldStatusValue !== '') {
                statusSelect.value = oldStatusValue;
            }

            function toggleFormFields(status) {
                var isActive = status === 'Ya';
                for (var key in fields) {
                    fields[key].required = isActive;
                    fields[key].disabled = !isActive;
                    if (!isActive) {
                        fields[key].value = ''; // Clear value if status is 'Tidak'
                    } else if (fields[key].value.trim() === '') {
                        fields[key].value = ''; // Clear field if status is 'Ya'
                    }
                }
            }

            statusSelect.addEventListener('change', function() {
                toggleFormFields(statusSelect.value);
            });

            // Initial check
            toggleFormFields(statusSelect.value);

            // Simpan nilai input ke local storage saat nilai diubah
            for (var key in fields) {
                fields[key].addEventListener('input', function(event) {
                    localStorage.setItem(event.target.id, event.target.value);
                });
            }

            // Hapus data local storage saat form disubmit
            var form = document.getElementById('modal-save-form');
            form.addEventListener('submit', function() {
                for (var key in fields) {
                    localStorage.removeItem(key);
                }
            });
        });
        // ===================================================================================
        // document.addEventListener("DOMContentLoaded", function() {
        //     var jenisImunisasiSelect = document.getElementById('jenis_imunisasi');

        //     // Field groups mapped by their corresponding dropdown value
        //     var fields = {
        //         'Usia 0 Bulan': ['hepatitis_b_0bln', 'bcg_0bln', 'polio_tetes_0bln'],
        //         'Usia 1 Bulan': ['bcg_1bln', 'polio_tetes_1_1bln'],
        //         'Usia 2 Bulan': ['dpt_hb_hib_1_2bln', 'polio_tetes_1_2bln', 'pcv_1_2bln', 'rv_1_2bln'],
        //         'Usia 3 Bulan': ['dpt_hb_hib_2_3bln', 'polio_tetes_2_3bln', 'pcv_2_3bln', 'rv_2_3bln'],
        //         'Usia 4 Bulan': ['dpt_hb_hib_3_4bln', 'polio_tetes_3_4bln', 'pcv_3_4bln', 'rv_3_4bln']
        //     };

        //     function toggleFormFields(selectElement, fieldElement, oldValue) {
        //         var isActive = selectElement.value === 'lainnya';
        //         fieldElement.disabled = !isActive;
        //         if (isActive) {
        //             fieldElement.value = oldValue || ''; // Gunakan nilai old jika ada, jika tidak kosongkan
        //         } else {
        //             fieldElement.value = '-';
        //         }
        //     }

        //     function fillImunisasiFields() {
        //         var selectedValue = jenisImunisasiSelect.value;
        //         for (var key in fields) {
        //             fields[key].forEach(function(id) {
        //                 var element = document.getElementById(id);
        //                 if (element) {
        //                     if (key === selectedValue) {
        //                         element.disabled = false;
        //                         var oldValue = element.getAttribute('data-old');
        //                         if (oldValue) {
        //                             element.value = oldValue;
        //                         }
        //                     } else {
        //                         element.disabled = true;
        //                         element.value =
        //                             'Tidak'; // Langsung pilih value "Tidak" pada formulir yang tidak aktif
        //                     }
        //                 }
        //             });
        //         }
        //         toggleFormFields(jenisImunisasiSelect, document.getElementById(selectedValue), document
        //             .getElementById(selectedValue).getAttribute('data-old'));
        //     }

        //     jenisImunisasiSelect.addEventListener('change', fillImunisasiFields);

        //     // Initial check
        //     fillImunisasiFields();
        // });

        // ===================================================================================
        document.getElementById('btnCekData').addEventListener('click', function() {
            var nik = document.getElementById('nik').value;

            Swal.fire({
                title: 'Checking...',
                text: 'Please wait while we check the data.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            fetch('<?php echo e(route('kunjungan_rumah_bayi.checkKK')); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    body: JSON.stringify({
                        nik: nik
                    })
                })
                .then(response => response.json())
                .then(data => {
                    Swal.close(); // Menutup loading SweetAlert2

                    if (data.status === 'success') {
                        document.getElementById('nama').value = data.data.nama;
                        document.getElementById('kk').value = data.data.kk;
                        Swal.fire({
                            icon: 'success',
                            title: 'NIK Ditemukan',
                            text: 'Nama: ' + data.data.nama
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message
                        });
                    }
                })
                .catch(error => {
                    Swal.close(); // Menutup loading SweetAlert2
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'There was an error checking the NIK.'
                    });
                    console.error('Error:', error);
                });
        });

        document.getElementById('modal-save-form').addEventListener('submit', function(event) {
            event.preventDefault(); // Mencegah submit default

            Swal.fire({
                title: 'Simpan...',
                text: 'Data Sedang Disimpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit form setelah menampilkan animasi loading
            this.submit();
        });
    </script>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Data Sedang Disimpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/kunjungan_rumah_bayi/createvalidate.blade.php ENDPATH**/ ?>