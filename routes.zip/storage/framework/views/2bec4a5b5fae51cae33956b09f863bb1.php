

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800 text-center"><?php echo e($title ?? __('List Tanggal Pengumpulan Data')); ?></h1>

        <!-- Buttons -->
        <div class="row mb-3">
            <div class="col text-center">
                <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                    <button class="btn btn-primary mb-2" onclick="window.location.href='<?php echo e(route('jadwal.createjad')); ?>'">
                        Tambah Data
                    </button>
                <?php endif; ?>

                <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                    <form action="<?php echo e(route('pendataan.index')); ?>" method="GET" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back
                        </button>
                    </form>
                <?php endif; ?>

                <form method="GET" action="<?php echo e(route('jadwalpengumpulan.index')); ?>" class="d-inline">
                    <button type="submit" class="btn btn-success" name="export" value="1"><i
                            class="fas fa-file-excel"></i> Export Excel</button>
                </form>
            </div>
        </div>

        <!-- Session Messages -->
        <?php if(session('message')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

        <!-- Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped" id="dataTable" style="text-align: center;">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Desa</th>
                        <th>Kartu Keluarga</th>
                        <th>Kepala Keluarga</th>
                        <th>No Handphome</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($jadwal->desa); ?></td>
                            <td><?php echo e($jadwal->kk); ?></td>
                            <td><?php echo e($jadwal->nama); ?></td>
                            <td><?php echo e($jadwal->no_hp); ?></td>
                            <td>
                                <div class="d-flex">
                                    <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                                        <button class="edit"
                                            onclick="window.location.href='<?php echo e(route('jadwal.edit', ['jadwal' => $jadwal->id])); ?>'">
                                            Edit
                                            <span></span>
                                        </button>

                                        


                                        <form action="<?php echo e(route('jadwal.destroy', $jadwal->id)); ?>" method="POST"
                                            onsubmit="">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger hidden">Hapus</button>
                                        </form>
                                        <form action="<?php echo e(route('jadwal.destroy', ['jadwal' => $jadwal->id])); ?>"
                                            method="post" class="delete-form">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="delete">
                                                <span class="delete__text">Hapus</span>
                                                <span class="delete__icon">
                                                    <svg class="svg" height="512" viewBox="0 0 512 512" width="512"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <title></title>
                                                        <path
                                                            d="M112,112l20,320c.95,18.49,14.4,32,32,32H348c17.67,0,30.87-13.51,32-32l20-320"
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                        </path>
                                                        <line
                                                            style="stroke:#fff;stroke-linecap:round;stroke-miterlimit:10;stroke-width:32px"
                                                            x1="80" x2="432" y1="112" y2="112">
                                                        </line>
                                                        <path
                                                            d="M192,112V72h0a23.93,23.93,0,0,1,24-24h80a23.93,23.93,0,0,1,24,24h0v40"
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                        </path>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="256" x2="256" y1="176" y2="400">
                                                        </line>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="184" x2="192" y1="176" y2="400">
                                                        </line>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="328" x2="320" y1="176" y2="400">
                                                        </line>
                                                    </svg>
                                                </span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <form method="GET" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="custom-btn btn-2" data-toggle="modal"
                                            data-target="#detailModal<?php echo e($jadwal->id); ?>">
                                            Detail
                                        </button>
                                        <!-- Modal -->
                                        <div class="modal fade" id="detailModal<?php echo e($jadwal->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Anggota
                                                            Keluarga
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <!-- Card View Content -->
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <!-- Table Content -->
                                                                <table class="table table-bordered">
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">Kepala Keluarga</th>
                                                                            <td><?php echo e($jadwal->nama); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Kartu Keluarga</th>
                                                                            <td><?php echo e($jadwal->kk); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Alamat</th>
                                                                            <td><?php echo e($jadwal->alamat); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">RT</th>
                                                                            <td><?php echo e($jadwal->rt); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">RW</th>
                                                                            <td><?php echo e($jadwal->rw); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Dusun</th>
                                                                            <td><?php echo e($jadwal->dusun); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Desa/Kelurahan</th>
                                                                            <td><?php echo e($jadwal->desa); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Kecamatan</th>
                                                                            <td><?php echo e($jadwal->kecamatan); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Kabupaten/Kota</th>
                                                                            <td><?php echo e($jadwal->kota); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Provinsi</th>
                                                                            <td><?php echo e($jadwal->provinsi); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">No Handphome</th>
                                                                            <td><?php echo e($jadwal->no_hp); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Puskesmas</th>
                                                                            <td><?php echo e($jadwal->puskesmas); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Postu/Posyandu Prima</th>
                                                                            <td><?php echo e($jadwal->postu); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Posyandu</th>
                                                                            <td><?php echo e($jadwal->posyandu); ?></td>
                                                                        </tr>


                                                                        <!-- Add more information fields here -->
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- End of Modal -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <style>
        .hidden {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".delete-form").on("submit", function(e) {
                e.preventDefault();
                const form = this;
                Swal.fire({
                    title: 'Apakah Anda Yakin?',
                    text: "Data akan dihapus secara permanen!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Ya, Hapus!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/jadwalpengumpulandata/list.blade.php ENDPATH**/ ?>