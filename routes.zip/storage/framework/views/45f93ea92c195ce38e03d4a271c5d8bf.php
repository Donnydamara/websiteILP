

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Update Data Kartu Keluarga')); ?></h1>

    <!-- Main Content goes here -->

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('pendataan_kk.updatedetail', ['id' => $data->id])); ?>" method="post" id="modal-save-form">

                <!-- Perubahan pada action -->
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Perubahan pada method -->

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kk">Kartu Keluarga</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kk"
                                id="kk" value="<?php echo e(old('kk') ?? $data->kk); ?>" required readonly>
                            <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama"
                                id="nama" placeholder="nama" autocomplete="off"
                                value="<?php echo e(old('nama') ?? $data->nama); ?>" required>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik"
                                id="nik" placeholder="NIK" autocomplete="off" value="<?php echo e(old('nik') ?? $data->nik); ?>"
                                required>
                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="tgl_lahir">Tanggal Lahir</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="tgl_lahir" id="tgl_lahir" autocomplete="off"
                                value="<?php echo e(old('tgl_lahir') ?? $data->tgl_lahir); ?>" required>
                            <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="gender">Jenis Kelamin</label>
                            <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" id="gender"
                                required>
                                <option value="">-- Select Gender --</option>
                                <option value="Laki-laki"
                                    <?php echo e(old('gender') ?? $data->gender == 'Laki-laki' ? 'selected' : ''); ?>>
                                    Laki-laki</option>
                                <option value="Perempuan"
                                    <?php echo e(old('gender') ?? $data->gender == 'Perempuan' ? 'selected' : ''); ?>>
                                    Perempuan</option>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="hubungan_keluarga">Hubungan Keluarga</label>
                            <select class="form-control <?php $__errorArgs = ['hubungan_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hubungan_keluarga" id="hubungan_keluarga" required>
                                <option value="">-- Pilih Hubungan Keluarga --</option>
                                <option value="Kepala Keluarga"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Kepala Keluarga' ? 'selected' : ''); ?>>
                                    Kepala Keluarga
                                </option>
                                <option value="Istri"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Istri' ? 'selected' : ''); ?>>
                                    Istri
                                </option>
                                <option value="Suami"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Suami' ? 'selected' : ''); ?>>
                                    Suami
                                </option>
                                <option value="Anak"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Anak' ? 'selected' : ''); ?>>
                                    Anak
                                </option>
                                <option value="Menantu"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Menantu' ? 'selected' : ''); ?>>
                                    Menantu
                                </option>
                                <option value="Cucu"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Cucu' ? 'selected' : ''); ?>>
                                    Cucu
                                </option>
                                <option value="Orang Tua"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Orang Tua' ? 'selected' : ''); ?>>
                                    Orang Tua
                                </option>
                                <option value="Famili Lain"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Famili Lain' ? 'selected' : ''); ?>>
                                    Famili Lain</option>
                                <option value="Pembantu Asisten Pekerja Lain"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Pembantu Asisten Pekerja Lain' ? 'selected' : ''); ?>>
                                    Pembantu/
                                    Asisten/ Pekerja Lain</option>
                                <option value="Lainnya"
                                    <?php echo e(old('hubungan_keluarga') ?? $data->hubungan_keluarga == 'Lainnya' ? 'selected' : ''); ?>>
                                    Lainnya
                                </option>
                            </select>
                            <?php $__errorArgs = ['hubungan_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="status_perkawinan">Status Perkawinan</label>
                            <select class="form-control <?php $__errorArgs = ['status_perkawinan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="status_perkawinan" id="status_perkawinan" required>
                                <option value="">-- Pilih Status Perkawinan --</option>
                                <option value="kawin"
                                    <?php echo e(old('status_perkawinan') ?? $data->status_perkawinan == 'kawin' ? 'selected' : ''); ?>>
                                    Kawin
                                </option>
                                <option value="belum_kawin"
                                    <?php echo e(old('status_perkawinan') ?? $data->status_perkawinan == 'belum_kawin' ? 'selected' : ''); ?>>
                                    Belum
                                    Kawin</option>
                                <option value="cerai_hidup"
                                    <?php echo e(old('status_perkawinan') ?? $data->status_perkawinan == 'cerai_hidup' ? 'selected' : ''); ?>>
                                    Cerai
                                    Hidup</option>
                                <option value="cerai_mati"
                                    <?php echo e(old('status_perkawinan') ?? $data->status_perkawinan == 'cerai_mati' ? 'selected' : ''); ?>>
                                    Cerai
                                    Mati</option>
                            </select>
                            <?php $__errorArgs = ['status_perkawinan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="pendidikan_terakhir">Pendidikan Terakhir</label>
                            <select class="form-control <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="pendidikan_terakhir" id="pendidikan_terakhir" required>
                                <option value="">-- Pilih Pendidikan Terakhir --</option>
                                <option value="S1 / S2 / S3"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'S1 / S2 / S3' ? 'selected' : ''); ?>>
                                    S1 / S2 /
                                    S3 (PT)</option>
                                <option value="D1 / D2 / D3"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'D1 / D2 / D3' ? 'selected' : ''); ?>>
                                    D1 / D2 /
                                    D3</option>
                                <option value="SMA Atau Sederajat"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'SMA Atau Sederajat' ? 'selected' : ''); ?>>
                                    SMA
                                    Atau
                                    Sederajat</option>
                                <option value="SMP Atau Sederajat"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'SMP Atau Sederajat' ? 'selected' : ''); ?>>
                                    SMP
                                    Atau
                                    Sederajat</option>
                                <option value="SD Atau Sederajat"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'SD Atau Sederajat' ? 'selected' : ''); ?>>
                                    SD Atau
                                    Sederajat
                                </option>
                                <option value="Tidak Pernah Sekolah"
                                    <?php echo e(old('pendidikan_terakhir') ?? $data->pendidikan_terakhir == 'Tidak Pernah Sekolah' ? 'selected' : ''); ?>>
                                    Tidak
                                    pernah
                                    sekolah</option>
                            </select>
                            <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="pekerjaan">Pekerjaan</label>
                            <select class="form-control <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pekerjaan"
                                id="pekerjaan" required>
                                <option value="">-- Pilih Pekerjaan --</option>
                                <option value="Tidak Bekerja"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Tidak Bekerja' ? 'selected' : ''); ?>>
                                    Tidak
                                    Bekerja</option>
                                <option value="Pelajar / Mahasiswa"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Pelajar / Mahasiswa' ? 'selected' : ''); ?>>
                                    Pelajar / Mahasiswa</option>
                                <option value="PNS / TNI-POLRI / BUMN / BUMD"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'PNS / TNI-POLRI / BUMN / BUMD' ? 'selected' : ''); ?>>
                                    PNS / TNI-POLRI /
                                    BUMN /
                                    BUMD</option>
                                <option value="Pegawai Swasta"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Pegawai Swasta' ? 'selected' : ''); ?>>
                                    Pegawai Swasta</option>
                                <option value="Wiraswasta"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Wiraswasta' ? 'selected' : ''); ?>>
                                    Wiraswasta
                                </option>
                                <option value="Petani Nelayan"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Petani Nelayan' ? 'selected' : ''); ?>>Petani
                                    / Nelayan</option>
                                <option value="Lainnya"
                                    <?php echo e(old('pekerjaan') ?? $data->pekerjaan == 'Lainnya' ? 'selected' : ''); ?>>Lainnya
                                </option>
                            </select>
                            <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kelompok_sasaran">Kelompok Sasaran</label>
                            <select class="form-control <?php $__errorArgs = ['kelompok_sasaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="kelompok_sasaran" id="kelompok_sasaran" required>
                                <option value="">-- Pilih Kelompok Sasaran --</option>
                                <option value="Ibu Hamil"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Ibu Hamil' ? 'selected' : ''); ?>>
                                    Ibu Hamil
                                </option>
                                <option value="Ibu Bersalin dan Lifas"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Ibu Bersalin dan Lifas' ? 'selected' : ''); ?>>
                                    Ibu
                                    Bersalin dan
                                    Lifas</option>
                                <option value="Bayi Balita (0 - 6 tahun)"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Bayi Balita (0 - 6 tahun)' ? 'selected' : ''); ?>>
                                    Bayi Balita (0 - 6 tahun)</option>
                                <option value="Usia Sekolah dan Remaja (>6 - <18 tahun)"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Usia Sekolah dan Remaja (>6 - <18 tahun)' ? 'selected' : ''); ?>>
                                    Usia Sekolah dan Remaja (>6 - <18 tahun) </option>
                                <option value="Usia Dewasa (>18 - 59 tahun)"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Usia Dewasa (>18 - 59 tahun)' ? 'selected' : ''); ?>>
                                    Usia Dewasa (>18 - 59 tahun)</option>
                                <option value="Usia Lansia"
                                    <?php echo e(old('kelompok_sasaran') ?? $data->kelompok_sasaran == 'Usia Lansia' ? 'selected' : ''); ?>>
                                    Usia Lansia</option>
                            </select>
                            <?php $__errorArgs = ['kelompok_sasaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Kembali Ke List</a>


            </form>
        </div>
    </div>

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Tunggu Data Sedang Di Simpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/pendataan_kk/editdetail.blade.php ENDPATH**/ ?>