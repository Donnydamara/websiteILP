

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('List Data Keluarga Dan Anggota Keluarga')); ?></h1>

    <!-- Main Content goes here -->

    
    

    <div class="row mb-3">
        <div class="col text-center">
            <!-- Tombol Tambah Data (untuk role 'kader') -->
            <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                <button class="btn btn-primary mb-2" onclick="window.location.href='<?php echo e(route('datakk.createvalidate')); ?>'">
                    Tambah Data
                </button>
            <?php endif; ?>

            <!-- Tombol Kembali (untuk role 'admin') -->
            <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                <form action="<?php echo e(route('pendataan.index')); ?>" method="GET" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary mb-2">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </button>
                </form>
            <?php endif; ?>



            <!-- Tombol Export Excel -->
            <form method="GET" action="<?php echo e(route('datakk.index')); ?>" class="d-inline">
                <button type="submit" class="btn btn-success mb-2" name="export" value="1">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </form>


        </div>
    </div>



    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>
    <div class="table-responsive" style="text-align: center">
        <table class="table table-bordered table-striped" id="dataTable">
            <thead>
                <tr>
                    <th style="text-align: center">No</th>
                    <th style="text-align: center">Kartu Keluarga</th>
                    <th style="text-align: center">Nama</th>
                    <th style="text-align: center">Gender</th>
                    <th style="text-align: center">Hubungan Keluarga</th>
                    <th style="text-align: center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dataKKs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($dataKK->kk); ?></td>
                        <td><?php echo e($dataKK->nama); ?></td>
                        <td><?php echo e($dataKK->gender); ?></td>
                        <td><?php echo e($dataKK->hubungan_keluarga); ?></td>
                        <td>
                            <div class="d-flex">
                                <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                                    <form action="<?php echo e(route('datakk.edit', ['id' => $dataKK->id])); ?>" method="GET"
                                        style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button class="edit">
                                            Edit
                                            <span></span>
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <form action="<?php echo e(route('datakk.show', ['id' => $dataKK->id])); ?>" method="GET"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <button class="custom-btn btn-2">
                                        Detail lengkap
                                    </button>
                                </form>


                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/pendataan_kk/list.blade.php ENDPATH**/ ?>