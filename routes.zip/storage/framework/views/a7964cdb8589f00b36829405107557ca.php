

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Tambah Target Desa ')); ?></h1>

    <!-- Main Content goes here -->

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('target-desa.store')); ?>" method="post" id="modal-save-form">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="provinsi">Provinsi</label>
                            <input type="text" class="form-control" id="provinsi" name="provinsi" value="Jawa Timur"
                                readonly required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kota">Kota</label>
                            <input type="text" class="form-control" id="kota" name="kota" value="Kab. Blitar"
                                readonly required>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kecamatan">Kecamatan</label>
                            <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="Kec. Selopuro"
                                readonly required>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="desa">Desa</label>
                            <select class="form-control <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desa" id="desa"
                                required>
                                <option value="" disabled selected>Pilih Desa</option>
                                <option value="Jambewangi">Jambewangi</option>
                                <option value="Jatitengah">Jatitengah</option>
                                <option value="Mandesan">Mandesan</option>
                                <option value="Mrojo">Mrojo</option>
                                <option value="Ploso">Ploso</option>
                                <option value="Popoh">Popoh</option>
                                <option value="Selopuro">Selopuro</option>
                                <option value="Tegalrejo">Tegalrejo</option>

                            </select>
                            <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="puskesmas">Puskesmas</label>
                            <input type="text" class="form-control" id="puskesmas" name="puskesmas"
                                value="UPT Puskesmas Selopuro" readonly required>
                        </div>

                        
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="target_penduduk">Target Penduduk</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['target_penduduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="target_penduduk" id="target_penduduk" placeholder="Target Penduduk" autocomplete="off"
                                value="<?php echo e(old('target_penduduk')); ?>" required>
                            <?php $__errorArgs = ['target_penduduk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                <a href="<?php echo e(route('target-desa.index')); ?>" class="btn btn-default">Kembali Ke List</a>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Data Sedang Disimpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/targetdesa/create.blade.php ENDPATH**/ ?>