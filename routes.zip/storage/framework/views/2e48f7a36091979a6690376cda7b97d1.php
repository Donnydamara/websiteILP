

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Create Data Ibu Hamil')); ?></h1>

    <!-- Main Content goes here -->

    <div class="card" style="text-align: center">
        <div class="card-body" style="text-align: center;">
            <form action="<?php echo e(route('ibu_hamil.store2')); ?>" method="POST" id="modal-save-form">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="status">Status Ibu Hamil</label>
                    <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="status" id="status"
                        required>
                        <option value="">Pilih</option>
                        <option value="Ya" <?php echo e(old('status') === 'Ya' ? 'selected' : ''); ?>>Ya</option>
                        <option value="Tidak" <?php echo e(old('status') === 'Tidak' ? 'selected' : ''); ?>>Tidak</option>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="card">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="kk">Kartu Keluarga</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['Kartu Keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="kk" id="kk" value="<?php echo e(old('kk', $kk)); ?>" required readonly>
                                <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="nama" id="nama" value="<?php echo e(old('nama', $nama)); ?>" required readonly>
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="nik">NIK</label>
                                <input type="hidden" name="nik" value="<?php echo e($nik); ?>">
                                <input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nik"
                                    value="<?php echo e($nik); ?>" readonly>
                                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="kehamilan_ke">Kehamilan Anak Ke</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['kehamilan_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kehamilan_ke" id="kehamilan_ke" placeholder="Kehamilan Ke" autocomplete="off"
                                        value="<?php echo e(old('kehamilan_ke')); ?>" required>
                                    <?php $__errorArgs = ['kehamilan_ke'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jarak_kehamilan">Jarak Kehamilan Dengan Kehamilan Sebelumnya</label>

                                    <select class="form-control" id="jarak_kehamilan_unit" name="jarak_kehamilan_unit"
                                        onchange="toggleInput()">
                                        <option value="bulan">Bulan</option>
                                        <option value="tahun">Tahun</option>
                                    </select>

                                    <input type="number"
                                        class="form-control mt-2 <?php $__errorArgs = ['jarak_kehamilan_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="jarak_kehamilan_bulan" id="jarak_kehamilan_bulan"
                                        placeholder="Masukkan dalam bulan" autocomplete="off"
                                        value="<?php echo e(old('jarak_kehamilan_bulan')); ?>">

                                    <input type="number"
                                        class="form-control mt-2 d-none <?php $__errorArgs = ['jarak_kehamilan_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="jarak_kehamilan_tahun" id="jarak_kehamilan_tahun"
                                        placeholder="Masukkan dalam tahun" autocomplete="off"
                                        value="<?php echo e(old('jarak_kehamilan_tahun')); ?>">

                                    <?php $__errorArgs = ['jarak_kehamilan_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    <?php $__errorArgs = ['jarak_kehamilan_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="umur">Umur Ibu</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="umur" id="umur" placeholder="Umur" autocomplete="off"
                                        value="<?php echo e(old('umur')); ?>" required>
                                    <?php $__errorArgs = ['umur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="kunjungan">Kunjungan</label>
                                    <input type="number" class="form-control <?php $__errorArgs = ['kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kunjungan" id="kunjungan" placeholder="Kunjungan" autocomplete="off"
                                        value="<?php echo e(old('kunjungan')); ?>" required>
                                    <?php $__errorArgs = ['kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tgl_kunjungan">Tanggal Kunjungan</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['tgl_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tgl_kunjungan" id="tgl_kunjungan" placeholder="tgl_Kunjungan"
                                        autocomplete="off" value="<?php echo e(old('tgl_kunjungan')); ?>" required>
                                    <?php $__errorArgs = ['tgl_kunjungan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="suhu_tubuh">Suhu Tubuh</label>
                                    <select class="form-control <?php $__errorArgs = ['suhu_tubuh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="suhu_tubuh" id="suhu_tubuh" required>
                                        <option value="">Pilih Suhu Tubuh</option>
                                        <option value="<37,5 C" <?php echo e(old('suhu_tubuh') == '<37,5 C' ? 'selected' : ''); ?>>
                                            &lt;
                                            37,5 C
                                        </option>
                                        <option value=">37,5 C" <?php echo e(old('suhu_tubuh') == '>37,5 C' ? 'selected' : ''); ?>>
                                            &gt;
                                            37,5 C
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['suhu_tubuh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <h5>Ada Buku KIA</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select class="form-control <?php $__errorArgs = ['kia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kia"
                                        id="kia" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('kia') == 'Ada' ? 'selected' : ''); ?>>Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('kia') == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['kia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <h5>Ibu Memeriksa Kehamilan</h5>
                                </div>
                            </div>
                        </div>
                        <div class="card" style="margin-top: 2%">
                            <div class="row" style="margin: 1%">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="jenis_imk">Ibu Memeriksa Kehamilan</label>
                                        <select class="form-control <?php $__errorArgs = ['jenis_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="jenis_imk" id="jenis_imk" required>
                                            <option value="">Pilih Trimester</option>
                                            <option value="K1 (Trimester I (1 kali pada umur kehamilan hingga 12 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K1 (Trimester I (1 kali pada umur kehamilan hingga 12 minggu))' ? 'selected' : ''); ?>>
                                                K1 (Trimester I (1 kali pada umur kehamilan hingga 12 minggu))
                                            </option>
                                            <option
                                                value="K2 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K2 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))' ? 'selected' : ''); ?>>
                                                K2 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))
                                            </option>
                                            <option
                                                value="K3 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K3 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))' ? 'selected' : ''); ?>>
                                                K3 (Trimester II (2 kali pada umur kehamilan hingga 12 - 24 minggu))
                                            </option>
                                            <option
                                                value="K4 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K4 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))' ? 'selected' : ''); ?>>
                                                K4 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))
                                            </option>
                                            <option
                                                value="K5 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K5 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))' ? 'selected' : ''); ?>>
                                                K5 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))
                                            </option>
                                            <option
                                                value="K6 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))"
                                                <?php echo e(old('jenis_imk') == 'K6 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))' ? 'selected' : ''); ?>>
                                                K6 (Trimester III (3 kali pada umur kehamilan hingga 24 - 40 minggu))
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['jenis_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tgl_imk">Tanggal</label>
                                        <input type="date" class="form-control <?php $__errorArgs = ['tgl_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="tgl_imk" id="tgl_imk" autocomplete="off"
                                            value="<?php echo e(old('tgl_imk')); ?>" required>
                                        <?php $__errorArgs = ['tgl_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="tempat_imk">Tempat</label>
                                        <select class="form-control <?php $__errorArgs = ['tempat_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="tempat_imk" id="tempat_imk" required>
                                            <option value="">Pilih Tempat</option>
                                            <option value="Rumah sakit"
                                                <?php echo e(old('tempat_imk') == 'Rumah sakit' ? 'selected' : ''); ?>>Rumah sakit
                                            </option>
                                            <option value="Puskesmas"
                                                <?php echo e(old('tempat_imk') == 'Puskesmas' ? 'selected' : ''); ?>>
                                                Puskesmas</option>
                                            <option value="Polindes"
                                                <?php echo e(old('tempat_imk') == 'Polindes' ? 'selected' : ''); ?>>
                                                Polindes</option>
                                            <option value="Dokter Praktik"
                                                <?php echo e(old('tempat_imk') == 'Dokter Praktik' ? 'selected' : ''); ?>>Dokter
                                                Praktik
                                            </option>
                                            <option value="Bidan praktik mandiri"
                                                <?php echo e(old('tempat_imk') == 'Bidan praktik mandiri' ? 'selected' : ''); ?>>Bidan
                                                praktik
                                                mandiri</option>
                                            <option value="Kader" <?php echo e(old('tempat_imk') == 'Kader' ? 'selected' : ''); ?>>
                                                Rumah
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['tempat_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="petugas_imk">Petugas</label>
                                        <select class="form-control <?php $__errorArgs = ['petugas_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="petugas_imk" id="petugas_imk" required>
                                            <option value="">Pilih Petugas</option>
                                            <option value="docter" <?php echo e(old('petugas_imk') == 'docter' ? 'selected' : ''); ?>>
                                                Docter
                                            </option>
                                            <option value="bidan" <?php echo e(old('petugas_imk') == 'bidan' ? 'selected' : ''); ?>>
                                                Bidan
                                            </option>
                                            <option value="perawat"
                                                <?php echo e(old('petugas_imk') == 'perawat' ? 'selected' : ''); ?>>
                                                Perawat</option>
                                            <option value="Kader" <?php echo e(old('petugas_imk') == 'Kader' ? 'selected' : ''); ?>>
                                                Kader</option>
                                        </select>
                                        <?php $__errorArgs = ['petugas_imk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <h5>TTD</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="ada_ttd">Ada TTD</label>
                                        <select class="form-control <?php $__errorArgs = ['ada_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="ada_ttd" id="ada_ttd" required>
                                            <option value="">Pilih Opsi</option>
                                            <option value="Ada" <?php echo e(old('ada_ttd') == 'Ada' ? 'selected' : ''); ?>>Ada
                                            </option>
                                            <option value="Tidak" <?php echo e(old('ada_ttd') == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['ada_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="minum_ttd">Minum TTD</label>
                                        <select class="form-control <?php $__errorArgs = ['minum_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="minum_ttd" id="minum_ttd" required>
                                            <option value="">Pilih Opsi</option>
                                            <option value="Ada" <?php echo e(old('minum_ttd') == 'Ada' ? 'selected' : ''); ?>>
                                                Ada
                                            </option>
                                            <option value="Tidak" <?php echo e(old('minum_ttd') == 'Tidak' ? 'selected' : ''); ?>>
                                                Tidak
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['minum_ttd'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="porsi">Isi Piringku Untuk Ibu Hamil</label>
                                        <select class="form-control <?php $__errorArgs = ['porsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="porsi"
                                            id="porsi" required>
                                            <option value="">Pilih Opsi</option>
                                            <option value="Sesuai" <?php echo e(old('porsi') == 'Sesuai' ? 'selected' : ''); ?>>Sesuai
                                            </option>
                                            <option value="Tidak" <?php echo e(old('porsi') == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['porsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="lila">LILA < 23,4 cm</label>
                                            <select class="form-control <?php $__errorArgs = ['lila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="lila" id="lila" required>
                                                <option value="">Pilih Opsi</option>
                                                <option value="Ada" <?php echo e(old('lila') == 'Ada' ? 'selected' : ''); ?>>
                                                    Ada
                                                </option>
                                                <option value="Tidak" <?php echo e(old('lila') == 'Tidak' ? 'selected' : ''); ?>>
                                                    Tidak
                                                </option>
                                            </select>
                                            <?php $__errorArgs = ['lila'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="pmt">PMT Untuk Bumil KEK</label>
                                    <select class="form-control <?php $__errorArgs = ['pmt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pmt"
                                        id="pmt" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('pmt') == 'Ada' ? 'selected' : ''); ?>>Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('pmt') == 'Tidak' ? 'selected' : ''); ?>>Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pmt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <h5>Mengikuti Kelas Ibu Hamil Terakhir</h5>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="kls_ibu_hamil">Tanggal</label>
                                    <input type="date"
                                        class="form-control <?php $__errorArgs = ['kls_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kls_ibu_hamil" id="kls_ibu_hamil" placeholder="kls ibu hamil"
                                        autocomplete="off" value="<?php echo e(old('kls_ibu_hamil')); ?>" required>
                                    <?php $__errorArgs = ['kls_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tempat_ibu_hamil">Tempat</label>
                                    <select class="form-control <?php $__errorArgs = ['tempat_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="tempat_ibu_hamil" id="tempat_ibu_hamil" required>
                                        <option value="">Pilih Tempat</option>
                                        <option value="Kantor desa"
                                            <?php echo e(old('tempat_ibu_hamil') == 'Kantor desa' ? 'selected' : ''); ?>>Kantor desa
                                        </option>
                                        <option value="posyandu"
                                            <?php echo e(old('tempat_ibu_hamil') == 'posyandu' ? 'selected' : ''); ?>>Posyandu</option>
                                    </select>
                                    <?php $__errorArgs = ['tempat_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="pendamping_ibu_hamil">Pendamping</label>
                                    <select class="form-control <?php $__errorArgs = ['pendamping_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="pendamping_ibu_hamil" id="pendamping_ibu_hamil" required>
                                        <option value="">Pilih Pendamping</option>
                                        <option value="suami"
                                            <?php echo e(old('pendamping_ibu_hamil') == 'suami' ? 'selected' : ''); ?>>
                                            Suami</option>
                                        <option value="saudara"
                                            <?php echo e(old('pendamping_ibu_hamil') == 'saudara' ? 'selected' : ''); ?>>Saudara
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['pendamping_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <h5>Melakukan Skrining Kesehatan Jiwa</h5>
                                </div>
                            </div>
                        </div>
                        <div class="card" style="margin-top: 2%">
                            <div class="row" style="margin: 1%">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="kls_skrining_kesehatan">Tanggal</label>
                                        <input type="date"
                                            class="form-control <?php $__errorArgs = ['kls_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="kls_skrining_kesehatan" id="kls_skrining_kesehatan"
                                            placeholder="kls_skrining_kesehatan" autocomplete="off"
                                            value="<?php echo e(old('kls_skrining_kesehatan')); ?>" required>
                                        <?php $__errorArgs = ['kls_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tempat_skrining_kesehatan">Tempat</label>
                                        <select
                                            class="form-control <?php $__errorArgs = ['tempat_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="tempat_skrining_kesehatan" id="tempat_skrining_kesehatan" required>
                                            <option value="">Pilih Tempat</option>
                                            <option value="Rumah"
                                                <?php echo e(old('tempat_skrining_kesehatan') == 'Rumah' ? 'selected' : ''); ?>>Rumah
                                            </option>
                                            <option value="Posyandu"
                                                <?php echo e(old('tempat_skrining_kesehatan') == 'Posyandu' ? 'selected' : ''); ?>>
                                                Posyandu
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['tempat_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="petugas_skrining_kesehatan">Petugas</label>
                                        <select
                                            class="form-control <?php $__errorArgs = ['petugas_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="petugas_skrining_kesehatan" id="petugas_skrining_kesehatan" required>
                                            <option value="">Pilih Petugas</option>
                                            <option value="Petugas Puskesmas"
                                                <?php echo e(old('petugas_skrining_kesehatan') == 'Petugas Puskesmas' ? 'selected' : ''); ?>>
                                                Petugas Puskesmas</option>
                                            <option value="Kader"
                                                <?php echo e(old('petugas_skrining_kesehatan') == 'Kader' ? 'selected' : ''); ?>>Kader
                                            </option>
                                        </select>
                                        <?php $__errorArgs = ['petugas_skrining_kesehatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="edukasi">Pemberian Edukasi/Kunjungan Nakes</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['edukasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="edukasi" id="edukasi" placeholder="Pemberian Edukasi/Kunjungan Nakes"
                                        autocomplete="off" value="<?php echo e(old('edukasi')); ?>" required>
                                    <?php $__errorArgs = ['edukasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="demam_l2">Demam Lebih Dari Dua Hari</label>
                                    <select class="form-control <?php $__errorArgs = ['demam_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="demam_l2"
                                        id="demam_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('demam_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('demam_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['demam_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="sakit_kepala_l2">Pusing/Sakit Kepala Berat</label>
                                    <select class="form-control <?php $__errorArgs = ['sakit_kepala_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="sakit_kepala_l2" id="sakit_kepala_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('sakit_kepala_l2') == 'Ada' ? 'selected' : ''); ?>>Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('sakit_kepala_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['sakit_kepala_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="sulit_tidur_l2">Sulit Tidur/Cemas Berlebih</label>
                                    <select class="form-control <?php $__errorArgs = ['sulit_tidur_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="sulit_tidur_l2" id="sulit_tidur_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('sulit_tidur_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('sulit_tidur_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['sulit_tidur_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="diare_l2">Diare Berulang</label>
                                    <select class="form-control <?php $__errorArgs = ['diare_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="diare_l2"
                                        id="diare_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('diare_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('diare_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['diare_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tbc_l2">Resiko TBC</label>
                                    <select class="form-control <?php $__errorArgs = ['tbc_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tbc_l2"
                                        id="tbc_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('tbc_l2') == 'Ada' ? 'selected' : ''); ?>>Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('tbc_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['tbc_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="gerakan_janin_l2">Tidak Ada Gerakan Janin</label>
                                    <select class="form-control <?php $__errorArgs = ['gerakan_janin_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="gerakan_janin_l2" id="gerakan_janin_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('gerakan_janin_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak"
                                            <?php echo e(old('gerakan_janin_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['gerakan_janin_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jantung_sakit_l2">Jantung Berdebar-Debar Dari Jalan Lahir</label>
                                    <select class="form-control <?php $__errorArgs = ['jantung_sakit_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="jantung_sakit_l2" id="jantung_sakit_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('jantung_sakit_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak"
                                            <?php echo e(old('jantung_sakit_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['jantung_sakit_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="keluar_cairan_l2">Keluar Cairan Dari Jalan Lahir</label>
                                    <select class="form-control <?php $__errorArgs = ['keluar_cairan_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="keluar_cairan_l2" id="keluar_cairan_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('keluar_cairan_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak"
                                            <?php echo e(old('keluar_cairan_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['keluar_cairan_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="kencing_manis_l2">Sakit Saat Kencing Manis</label>
                                    <select class="form-control <?php $__errorArgs = ['kencing_manis_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="kencing_manis_l2" id="kencing_manis_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('kencing_manis_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak"
                                            <?php echo e(old('kencing_manis_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['kencing_manis_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card" style="margin-top: 2%">
                        <div class="row" style="margin: 1%">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="nyeri_perut_l2">Nyeri Perut Hebat</label>
                                    <select class="form-control <?php $__errorArgs = ['nyeri_perut_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="nyeri_perut_l2" id="nyeri_perut_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('nyeri_perut_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('nyeri_perut_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['nyeri_perut_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="periksa_l2">Mengingatkan Periksa Ke Postu/Fasyankes</label>
                                    <select class="form-control <?php $__errorArgs = ['periksa_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="periksa_l2" id="periksa_l2" required>
                                        <option value="">Pilih Opsi</option>
                                        <option value="Ada" <?php echo e(old('periksa_l2') == 'Ada' ? 'selected' : ''); ?>>
                                            Ada
                                        </option>
                                        <option value="Tidak" <?php echo e(old('periksa_l2') == 'Tidak' ? 'selected' : ''); ?>>
                                            Tidak
                                        </option>
                                    </select>
                                    <?php $__errorArgs = ['periksa_l2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="lapor_nakes">Melaporkan Ke Nakes</label>
                                    <input type="date" class="form-control <?php $__errorArgs = ['lapor_nakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="lapor_nakes" id="lapor_nakes" placeholder="lapor_nakes" autocomplete="off"
                                        value="<?php echo e(old('lapor_nakes')); ?>" required>
                                    <?php $__errorArgs = ['lapor_nakes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                            <?php if(isset($kk)): ?>
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Kembali Ke Detail</a>
                            <?php endif; ?>

                        </div>
            </form>
        </div>
    </div>


    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var statusSelect = document.getElementById('status');
            var fields = {
                'nik': document.getElementById('nik'),
                'nama': document.getElementById('nama'),
                'kehamilan_ke': document.getElementById('kehamilan_ke'),
                // 'jarak_kehamilan': document.getElementById('jarak_kehamilan'),
                'jarak_kehamilan_unit': document.getElementById('jarak_kehamilan_unit'),
                'jarak_kehamilan_bulan': document.getElementById('jarak_kehamilan_bulan'),
                'jarak_kehamilan_tahun': document.getElementById('jarak_kehamilan_tahun'),
                'umur': document.getElementById('umur'),
                'kunjungan': document.getElementById('kunjungan'),
                'tgl_kunjungan': document.getElementById('tgl_kunjungan'),
                'suhu_tubuh': document.getElementById('suhu_tubuh'),
                'kia': document.getElementById('kia'),
                'jenis_imk': document.getElementById('jenis_imk'),
                'tgl_imk': document.getElementById('tgl_imk'),
                'tempat_imk': document.getElementById('tempat_imk'),
                'petugas_imk': document.getElementById('petugas_imk'),
                'porsi': document.getElementById('porsi'),
                'ada_ttd': document.getElementById('ada_ttd'),
                'minum_ttd': document.getElementById('minum_ttd'),
                'lila': document.getElementById('lila'),
                'pmt': document.getElementById('pmt'),
                'kls_ibu_hamil': document.getElementById('kls_ibu_hamil'),
                'tempat_ibu_hamil': document.getElementById('tempat_ibu_hamil'),
                'pendamping_ibu_hamil': document.getElementById('pendamping_ibu_hamil'),
                'kls_skrining_kesehatan': document.getElementById('kls_skrining_kesehatan'),
                'tempat_skrining_kesehatan': document.getElementById('tempat_skrining_kesehatan'),
                'petugas_skrining_kesehatan': document.getElementById('petugas_skrining_kesehatan'),
                'edukasi': document.getElementById('edukasi'),
                'demam_l2': document.getElementById('demam_l2'),
                'sakit_kepala_l2': document.getElementById('sakit_kepala_l2'),
                'sulit_tidur_l2': document.getElementById('sulit_tidur_l2'),
                'diare_l2': document.getElementById('diare_l2'),
                'tbc_l2': document.getElementById('tbc_l2'),
                'gerakan_janin_l2': document.getElementById('gerakan_janin_l2'),
                'jantung_sakit_l2': document.getElementById('jantung_sakit_l2'),
                'keluar_cairan_l2': document.getElementById('keluar_cairan_l2'),
                'kencing_manis_l2': document.getElementById('kencing_manis_l2'),
                'nyeri_perut_l2': document.getElementById('nyeri_perut_l2'),
                'periksa_l2': document.getElementById('periksa_l2'),
                'lapor_nakes': document.getElementById('lapor_nakes')
            };

            // Memeriksa jika ada data tersimpan di local storage
            for (var key in fields) {
                var storedValue = localStorage.getItem(key);
                if (storedValue !== null) {
                    fields[key].value = storedValue;
                }
            }

            // Set nilai dropdown "Status Ibu Bersalin Nifas" menggunakan old value jika ada
            var oldStatusValue = "<?php echo e(old('status')); ?>";
            if (oldStatusValue !== '') {
                statusSelect.value = oldStatusValue;
            }

            function toggleFormFields(status) {
                var isActive = status === 'Ya';
                for (var key in fields) {
                    fields[key].required = isActive;
                    fields[key].disabled = !isActive;
                    if (isActive && fields[key].value.trim() === '') {
                        fields[key].value = ''; // Hanya menghapus nilai jika statusnya aktif dan nilai tidak kosong
                    }
                }
            }

            statusSelect.addEventListener('change', function() {
                toggleFormFields(statusSelect.value);
            });

            // Initial check
            toggleFormFields(statusSelect.value);

            // Simpan nilai input ke local storage saat nilai diubah
            for (var key in fields) {
                fields[key].addEventListener('input', function(event) {
                    localStorage.setItem(event.target.id, event.target.value);
                });
            }

            // Hapus data local storage saat form disubmit
            var form = document.getElementById('modal-save-form');
            form.addEventListener('submit', function() {
                for (var key in fields) {
                    localStorage.removeItem(key);
                }
            });
        });
        //================================
        function toggleInput() {
            var unit = document.getElementById('jarak_kehamilan_unit').value;
            var bulanInput = document.getElementById('jarak_kehamilan_bulan');
            var tahunInput = document.getElementById('jarak_kehamilan_tahun');

            if (unit === 'bulan') {
                bulanInput.classList.remove('d-none');
                tahunInput.classList.add('d-none');
            } else {
                bulanInput.classList.add('d-none');
                tahunInput.classList.remove('d-none');
            }
        }

        // Initialize the input visibility based on the current selection
        toggleInput();
        // ===================================================================================
    </script>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Data Sedang Disimpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/ibu_hamil/createdetail.blade.php ENDPATH**/ ?>