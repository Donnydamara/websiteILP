

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Update Data Lingkungan Rumah')); ?></h1>

    <!-- Main Content goes here -->

    <div class="card"style="text-align: center">
        <div class="card-body">
            <form action="<?php echo e(route('lingkunganrumah.update', $lingkunganRumah->id)); ?>" method="post" id="modal-save-form">

                <!-- Perubahan pada action -->
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- Perubahan pada method -->
                <div class="card">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kk">No Kartu Keluarga</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kk"
                                    id="kk" placeholder="KK" autocomplete="off" value="<?php echo e($lingkunganRumah->kk); ?>"
                                    required>
                                <!-- Populate KK from session -->
                                <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nama">Nama kepala keluarga</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="nama" id="nama" placeholder="Nama kepala keluarga" autocomplete="off"
                                    value="<?php echo e($lingkunganRumah->nama); ?>" required>
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 1%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-12">
                            <div class="form-group text-center">
                                <h5>Data Anggota Rumah Tangga</h5>
                            </div>
                        </div>
                        <div class="card" style="margin-top: 1%">
                            <div class="row" style="margin: 1%">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AK_total">Jumlah Anggota Keluarga</label>
                                        <input type="number" class="form-control <?php $__errorArgs = ['AK_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_total" id="AK_total" placeholder="Jumlah Anggota Keluarga"
                                            autocomplete="off" value="<?php echo e($lingkunganRumah->AK_total); ?>" required>
                                        <?php $__errorArgs = ['AK_total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AK_lansia">Jumlah Anggota Keluarga Lansia (>60 tahun)</label>
                                        <input type="number" class="form-control <?php $__errorArgs = ['AK_lansia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_lansia" id="AK_lansia"
                                            placeholder="Jumlah Anggota Keluarga Lansia (>60 tahun)" autocomplete="off"
                                            value="<?php echo e($lingkunganRumah->AK_lansia); ?>" required>
                                        <?php $__errorArgs = ['AK_lansia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="jumlah_AK_dewasa">Jumlah Anggota Keluarga Usia Dewasa (>18-59
                                            Tahun)</label>
                                        <input type="number"
                                            class="form-control <?php $__errorArgs = ['jumlah_AK_dewasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="jumlah_AK_dewasa" id="jumlah_AK_dewasa"
                                            placeholder="Jumlah Anggota Keluarga Usia Dewasa (>18 - 59 Tahun)"
                                            autocomplete="off" value="<?php echo e($lingkunganRumah->jumlah_AK_dewasa); ?>" required>
                                        <?php $__errorArgs = ['jumlah_AK_dewasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card" style="margin-top: 1%">
                            <div class="row" style="margin: 1%">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AK_remaja">Jumlah Anggota Keluarga Usia Sekolah Dan Remaja (>6 - < 18
                                                Tahun)</label>
                                                <input type="number"
                                                    class="form-control <?php $__errorArgs = ['AK_remaja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    name="AK_remaja" id="AK_remaja"
                                                    placeholder="Jumlah Anggota Keluarga Usia Sekolah Dan Remaja (>6 - < 18 Tahun)"
                                                    autocomplete="off" value="<?php echo e($lingkunganRumah->AK_remaja); ?>" required>
                                                <?php $__errorArgs = ['AK_remaja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AK_balita">Jumlah Anggota Keluarga Balita (6 - 7 Bulan)</label>
                                        <input type="number" class="form-control <?php $__errorArgs = ['AK_balita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_balita" id="AK_balita"
                                            placeholder="Jumlah Anggota Keluarga Balita (6 - 7 Bulan)" autocomplete="off"
                                            value="<?php echo e($lingkunganRumah->AK_balita); ?>" required>
                                        <?php $__errorArgs = ['AK_balita'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="AK_bayi">Jumlah Anggota Keluarga Bayi (0-6 Bulan)</label>
                                        <input type="number" class="form-control <?php $__errorArgs = ['AK_bayi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_bayi" id="AK_bayi"
                                            placeholder="Jumlah Anggota Keluarga Bayi (0-6 Bulan)" autocomplete="off"
                                            value="<?php echo e($lingkunganRumah->AK_bayi); ?>" required>
                                        <?php $__errorArgs = ['AK_bayi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card" style="margin-top: 1%">
                            <div class="row" style="margin: 1%">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="AK_ibu_bersalin_nifas">Jumlah Anggota Keluarga Ibu Bersalin
                                            Nifas</label>
                                        <input type="number"
                                            class="form-control <?php $__errorArgs = ['AK_ibu_bersalin_nifas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_ibu_bersalin_nifas" id="AK_ibu_bersalin_nifas"
                                            placeholder="Jumlah Anggota Keluarga Ibu Bersalin Nifas" autocomplete="off"
                                            value="<?php echo e($lingkunganRumah->AK_ibu_bersalin_nifas); ?>" required>
                                        <?php $__errorArgs = ['AK_ibu_bersalin_nifas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="AK_ibu_hamil">Jumlah Anggota Keluarga Ibu Hamil</label>
                                        <input type="number"
                                            class="form-control <?php $__errorArgs = ['AK_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name="AK_ibu_hamil" id="AK_ibu_hamil"
                                            placeholder="Jumlah Anggota Keluarga Ibu Hamil" autocomplete="off"
                                            value="<?php echo e($lingkunganRumah->AK_ibu_hamil); ?>" required>
                                        <?php $__errorArgs = ['AK_ibu_hamil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 1%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jkn_jamkesda">Apakah memiliki Jaminan Kesehatan Nasional (JKN)/ Jaminan
                                    Kesehatan
                                    (Jamkesda)/ Asuransi Kesehatan</label>
                                <select class="form-control <?php $__errorArgs = ['jkn_jamkesda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jkn_jamkesda" id="jkn_jamkesda" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya" <?php echo e($lingkunganRumah->jkn_jamkesda == 'Ya' ? 'selected' : ''); ?>>
                                        Ya
                                    </option>
                                    <option value="Tidak"
                                        <?php echo e($lingkunganRumah->jkn_jamkesda == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['jkn_jamkesda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="sarana_air">Apakah tersedia sarana air bersih di lingkungan
                                    rumah</label>
                                <select class="form-control <?php $__errorArgs = ['sarana_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sarana_air"
                                    id="sarana_air" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya" <?php echo e($lingkunganRumah->sarana_air == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak"
                                        <?php echo e($lingkunganRumah->sarana_air == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['sarana_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jenis_sumber_air">Bila YA apa jenis sumber airnya terlindungi</label>
                                <select class="form-control <?php $__errorArgs = ['jenis_sumber_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jenis_sumber_air" id="jenis_sumber_air">
                                    <option value="">Pilih</option>
                                    <option value="Ya(PDAM, Sumur, Pompa, Sumur Gali Terlindung, Mata Air Terlindung)"
                                        <?php echo e($lingkunganRumah->jenis_sumber_air == 'Ya(PDAM, Sumur, Pompa, Sumur Gali Terlindung, Mata Air Terlindung)' ? 'selected' : ''); ?>>
                                        Ya(PDAM, Sumur, Pompa, Sumur Gali Terlindung, Mata Air Terlindung)
                                    </option>
                                    <option value="Tidak (Sumur Terbuka, Air Sungai, Danau / Telaga Dll)"
                                        <?php echo e($lingkunganRumah->jenis_sumber_air == 'Tidak (Sumur Terbuka, Air Sungai, Danau / Telaga Dll)' ? 'selected' : ''); ?>>
                                        Tidak (Sumur Terbuka, Air Sungai, Danau / Telaga Dll)
                                    </option>
                                </select>
                                <?php $__errorArgs = ['jenis_sumber_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 1%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jamban">Apakah tersedia jamban</label>
                                <select class="form-control <?php $__errorArgs = ['jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jamban"
                                    id="jamban" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya" <?php echo e($lingkunganRumah->jamban == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e($lingkunganRumah->jamban == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="jenis_jamban">Bila YA apakah jenis jambannya saniter?</label>
                                <select class="form-control <?php $__errorArgs = ['jenis_jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="jenis_jamban" id="jenis_jamban" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya (Kloset / Leher Angsa / Plengsengan)"
                                        <?php echo e($lingkunganRumah->jenis_jamban == 'Ya (Kloset / Leher Angsa / Plengsengan)' ? 'selected' : ''); ?>>
                                        Ya (Kloset / Leher Angsa / Plengsengan)
                                    </option>
                                    <option value="Tidak (Cemplung)"
                                        <?php echo e($lingkunganRumah->jenis_jamban == 'Tidak (Cemplung)' ? 'selected' : ''); ?>>
                                        Tidak (Cemplung)
                                    </option>
                                </select>
                                <?php $__errorArgs = ['jenis_jamban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="ventilasi">Apakah Rumah Memiliki Ventilasi</label>
                                <select class="form-control <?php $__errorArgs = ['ventilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ventilasi"
                                    id="ventilasi" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya" <?php echo e($lingkunganRumah->ventilasi == 'Ya' ? 'selected' : ''); ?>>Ya
                                    </option>
                                    <option value="Tidak" <?php echo e($lingkunganRumah->ventilasi == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['ventilasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" style="margin-top: 1%">
                    <div class="row" style="margin: 1%">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="mengalami_gangguan_jiwa">Apakah ada anggota keluarga yang mengalami
                                    gangguan
                                    jiwa</label>
                                <select class="form-control <?php $__errorArgs = ['mengalami_gangguan_jiwa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="mengalami_gangguan_jiwa" id="mengalami_gangguan_jiwa" required>
                                    <option value="">Pilih</option>
                                    <option value="Ya"
                                        <?php echo e($lingkunganRumah->mengalami_gangguan_jiwa == 'Ya' ? 'selected' : ''); ?>>
                                        Ya</option>
                                    <option value="Tidak"
                                        <?php echo e($lingkunganRumah->mengalami_gangguan_jiwa == 'Tidak' ? 'selected' : ''); ?>>
                                        Tidak
                                    </option>
                                </select>
                                <?php $__errorArgs = ['mengalami_gangguan_jiwa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="TBC_hipertensi_millitus">Apakah ada anggota keluarga yang terdiaknosa
                                    (TBC,
                                    Hipertensi dan
                                    Diabetes Mellitus)</label>
                                <select class="form-control <?php $__errorArgs = ['TBC_hipertensi_millitus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="TBC_hipertensi_millitus" id="TBC_hipertensi_millitus" required>
                                    <option value="">Pilih</option>
                                    <option value="TBC"
                                        <?php echo e($lingkunganRumah->TBC_hipertensi_millitus == 'TBC' ? 'selected' : ''); ?>>
                                        TBC
                                    </option>
                                    <option value="Hipertensi"
                                        <?php echo e($lingkunganRumah->TBC_hipertensi_millitus == 'Hipertensi' ? 'selected' : ''); ?>>
                                        Hipertensi</option>
                                    <option value="Diabetes Melitus"
                                        <?php echo e($lingkunganRumah->TBC_hipertensi_millitus == 'Diabetes Melitus' ? 'selected' : ''); ?>>
                                        Diabetes Melitus
                                    </option>
                                </select>
                                <?php $__errorArgs = ['TBC_hipertensi_millitus'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                    <a href="<?php echo e(route('lingkunganrumah.index')); ?>" class="btn btn-default">Kembali Ke List</a>
                </div>
                <!-- Tambahkan input field lainnya sesuai dengan kolom yang ada pada tabel -->


            </form>
        </div>
    </div>

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Tunggu Data Sedang Di Simpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/lingkunganrumah/edit.blade.php ENDPATH**/ ?>