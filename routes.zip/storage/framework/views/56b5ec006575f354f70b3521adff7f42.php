

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Tambah Jadwal Pengumpulan')); ?></h1>

    <!-- Main Content goes here -->
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>
    <div class="card">
        <div class="progress">
            <div class="progress-bar" role="progressbar" style="width: 10%;" aria-valuenow="25" aria-valuemin="0"
                aria-valuemax="100">10%</div>
        </div>
        <div class="card-body">

            
            <form id="target-desa-form" action="<?php echo e(route('jadwal.storejad')); ?>" method="post">
                <!-- Perubahan pada action -->
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="puskesmas">Puskesmas</label>
                            <select class="form-control <?php $__errorArgs = ['puskesmas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="puskesmas"
                                id="puskesmas" required>
                                <option value="">Pilih Puskesmas</option>
                                <?php $__currentLoopData = $puskesmasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puskesmas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($puskesmas); ?>"><?php echo e($puskesmas); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['puskesmas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="provinsi">Provinsi</label>
                            <select class="form-control <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="provinsi"
                                id="provinsi" required>
                                <option value="">Pilih Provinsi</option>
                            </select>
                            <?php $__errorArgs = ['provinsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kota">Kabupaten/Kota</label>
                            <select class="form-control <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kota" id="kota"
                                required>
                                <option value="">Pilih Kabupaten/Kota</option>
                            </select>
                            <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kecamatan">Kecamatan</label>
                            <select class="form-control <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kecamatan"
                                id="kecamatan" required>
                                <option value="">Pilih Kecamatan</option>
                            </select>
                            <?php $__errorArgs = ['kecamatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="desa">Desa/Kelurahan</label>
                            <select class="form-control <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="desa" id="desa"
                                required>
                                <option value="">Pilih Desa/Kelurahan</option>
                            </select>
                            <?php $__errorArgs = ['desa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="dusun">Dusun</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['dusun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="dusun"
                                id="dusun" placeholder="dusun" autocomplete="off" value="<?php echo e(old('dusun')); ?>" required>
                            <?php $__errorArgs = ['dusun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat"
                                id="alamat" placeholder="Alamat" autocomplete="off" value="<?php echo e(old('alamat')); ?>"
                                required>
                            <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="rt">RT</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rt"
                                id="rt" placeholder="RT" autocomplete="off" value="<?php echo e(old('rt')); ?>" required>
                            <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="rw">RW</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rw"
                                id="rw" placeholder="RW" autocomplete="off" value="<?php echo e(old('rw')); ?>" required>
                            <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>


                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="postu">Postu/Posyandu Prima</label>
                            <input type="text" class="form-control" id="postu" name="postu"
                                value="Popoh Selopuro" readonly required>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="posyandu">Posyandu</label>
                            <select class="form-control <?php $__errorArgs = ['posyandu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="posyandu"
                                id="posyandu" required>
                                <option value="" disabled selected>Pilih Posyandu</option>
                                <option value="KRAJAN" <?php echo e(old('posyandu') == 'KRAJAN' ? 'selected' : ''); ?>>KRAJAN</option>
                                <option value="SUMBERTOK" <?php echo e(old('posyandu') == 'SUMBERTOK' ? 'selected' : ''); ?>>SUMBERTOK
                                </option>
                                <option value="TUMPAKPURI" <?php echo e(old('posyandu') == 'TUMPAKPURI' ? 'selected' : ''); ?>>
                                    TUMPAKPURI</option>
                                <option value="ANGGREK" <?php echo e(old('posyandu') == 'ANGGREK' ? 'selected' : ''); ?>>ANGGREK
                                </option>
                                <option value="DAHLIA" <?php echo e(old('posyandu') == 'DAHLIA' ? 'selected' : ''); ?>>DAHLIA</option>
                                <option value="DELIMA" <?php echo e(old('posyandu') == 'DELIMA' ? 'selected' : ''); ?>>DELIMA</option>
                                <option value="MAWAR" <?php echo e(old('posyandu') == 'MAWAR' ? 'selected' : ''); ?>>MAWAR</option>
                                <option value="MELATI" <?php echo e(old('posyandu') == 'MELATI' ? 'selected' : ''); ?>>MELATI</option>
                                <option value="BANYUSONGO" <?php echo e(old('posyandu') == 'BANYUSONGO' ? 'selected' : ''); ?>>
                                    BANYUSONGO</option>
                                <option value="NGGERO" <?php echo e(old('posyandu') == 'NGGERO' ? 'selected' : ''); ?>>NGGERO</option>
                                <option value="GENTUNGAN" <?php echo e(old('posyandu') == 'GENTUNGAN' ? 'selected' : ''); ?>>GENTUNGAN
                                </option>
                                <option value="ILIK ILIK" <?php echo e(old('posyandu') == 'ILIK ILIK' ? 'selected' : ''); ?>>ILIK ILIK
                                </option>
                                <option value="PAKEL" <?php echo e(old('posyandu') == 'PAKEL' ? 'selected' : ''); ?>>PAKEL</option>
                                <option value="RINGINREJO" <?php echo e(old('posyandu') == 'RINGINREJO' ? 'selected' : ''); ?>>
                                    RINGINREJO</option>
                                <option value="POS I" <?php echo e(old('posyandu') == 'POS I' ? 'selected' : ''); ?>>POS I</option>
                                <option value="POS II" <?php echo e(old('posyandu') == 'POS II' ? 'selected' : ''); ?>>POS II</option>
                                <option value="POS III" <?php echo e(old('posyandu') == 'POS III' ? 'selected' : ''); ?>>POS III
                                </option>
                                <option value="POS IV" <?php echo e(old('posyandu') == 'POS IV' ? 'selected' : ''); ?>>POS IV</option>
                                <option value="POS V" <?php echo e(old('posyandu') == 'POS V' ? 'selected' : ''); ?>>POS V</option>
                                <option value="POS VI" <?php echo e(old('posyandu') == 'POS VI' ? 'selected' : ''); ?>>POS VI</option>
                            </select>
                            <?php $__errorArgs = ['posyandu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="no_hp">No Handphome</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="no_hp" id="no_hp" placeholder="No Handphome" autocomplete="off"
                                value="<?php echo e(old('no_hp')); ?>" required>
                            <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="nama">Nama Kepala Keluarga</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="nama" id="nama" placeholder="Nama Kepala Keluarga" autocomplete="off"
                                value="<?php echo e(old('nama')); ?>" required>
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kk">Kartu Keluarga</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kk"
                                id="kk" placeholder="Kartu Keluarga" autocomplete="off"
                                value="<?php echo e(old('kk')); ?>" required>
                            <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" onclick="setAction('save')">Simpan</button>
                <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-default">Kembali Ke List</a>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('puskesmas').addEventListener('change', function() {
            var puskesmas = this.value;
            fetch(`/getDesaByPuskesmas?puskesmas=${puskesmas}`)
                .then(response => response.json())
                .then(data => {
                    // Clear previous options
                    ['provinsi', 'kota', 'kecamatan', 'desa'].forEach(id => {
                        document.getElementById(id).innerHTML = '<option value="">Pilih</option>';
                    });

                    data.forEach(item => {
                        document.getElementById('provinsi').innerHTML +=
                            `<option value="${item.provinsi}">${item.provinsi}</option>`;
                        document.getElementById('kota').innerHTML +=
                            `<option value="${item.kota}">${item.kota}</option>`;
                        document.getElementById('kecamatan').innerHTML +=
                            `<option value="${item.kecamatan}">${item.kecamatan}</option>`;
                        document.getElementById('desa').innerHTML +=
                            `<option value="${item.desa}">${item.desa}</option>`;
                    });
                });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/jadwalpengumpulandata/create.blade.php ENDPATH**/ ?>