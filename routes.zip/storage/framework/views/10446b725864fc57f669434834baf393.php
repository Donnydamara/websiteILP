

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('List Data Kunjungan Rumah Bayi')); ?></h1>

    <!-- Main Content goes here -->

    
    <div class="row mb-3">
        <div class="col text-center">
            <!-- Tombol Create untuk role 'kader' -->
            <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                <button class="btn btn-primary mb-2"
                    onclick="window.location.href='<?php echo e(route('kunjungan_rumah_bayi.createvalidate')); ?>'">
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24">
                            <path fill="none" d="M0 0h24v24H0z"></path>
                            <path fill="currentColor" d="M11 11V5h2v6h6v2h-6v6h-2v-6H5v-2z"></path>
                        </svg>
                        Tambah Data
                    </span>
                </button>
            <?php endif; ?>

            <!-- Tombol Kembali untuk role 'admin' -->
            <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                <form action="<?php echo e(route('pendataan.index')); ?>" method="GET" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary mb-2">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </button>
                </form>
            <?php endif; ?>

            <!-- Dropdown Filter Status -->
            <form method="GET" action="<?php echo e(route('kunjungan_rumah_bayi.index')); ?>" class="d-inline mb-2">
                <select name="status" class="form-select" onchange="this.form.submit()"
                    style="display: inline-block; width: auto;">
                    <option value="ya" <?php echo e($status == 'ya' ? 'selected' : ''); ?>>Ya</option>
                    <option value="selesai" <?php echo e($status == 'selesai' ? 'selected' : ''); ?>>Selesai</option>
                    <option value="semua" <?php echo e($status == 'semua' ? 'selected' : ''); ?>>Semua</option>
                </select>
            </form>

            <!-- Tombol Export ke Excel -->
            <form action="<?php echo e(route('kunjungan_rumah_bayi.export')); ?>" method="GET" class="d-inline">
                <input type="hidden" name="status" value="<?php echo e($status); ?>">
                <input type="hidden" name="export" value="true">
                <button type="submit" class="btn btn-success mb-2">
                    <i class="fas fa-file-excel"></i> Export to Excel
                </button>
            </form>
        </div>
    </div>

    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>

    <div class="table-responsive" style="text-align: center">
        <table class="table table-bordered table-striped" id="dataTable">
            <thead>
                <tr>
                    <th style="text-align: center">No</th>
                    <th style="text-align: center">Status Kunjungan <br> Rumah Bayi</th>
                    <th style="text-align: center">Kartu Keluarga</th>
                    <th style="text-align: center">NIK</th>
                    <th style="text-align: center">Nama</th>
                    <th style="text-align: center">Jenis Kelamin</th>
                    <th style="text-align: center">Kunjungan</th>
                    <th style="text-align: center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kunjunganrumahBayis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                        <td class="status-box" style="color: #fff"><?php echo e($dataKK->status); ?></td>
                        <td><?php echo e($dataKK->kk); ?></td>
                        <td><?php echo e($dataKK->nik); ?></td>
                        <td><?php echo e($dataKK->nama); ?></td>
                        <td><?php echo e($dataKK->gender); ?></td>
                        <td><?php echo e($dataKK->kunjungan); ?></td>
                        <td>
                            <div class="d-flex">
                                <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                                    <form action="<?php echo e(route('kunjungan_rumah_bayi.edit', ['id' => $dataKK->id])); ?>"
                                        method="GET" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button class="edit">
                                            Edit
                                            <span></span>
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('kunjungan_rumah_bayi.destroy', ['id' => $dataKK->id])); ?>"
                                        method="post" class="delete-form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="delete">
                                            <span class="delete__text">Delete</span>
                                            <span class="delete__icon">
                                                <svg class="svg" height="512" viewBox="0 0 512 512" width="512"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <title></title>
                                                    <path
                                                        d="M112,112l20,320c.95,18.49,14.4,32,32,32H348c17.67,0,30.87-13.51,32-32l20-320"
                                                        style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                    </path>
                                                    <line
                                                        style="stroke:#fff;stroke-linecap:round;stroke-miterlimit:10;stroke-width:32px"
                                                        x1="80" x2="432" y1="112" y2="112"></line>
                                                    <path
                                                        d="M192,112V72h0a23.93,23.93,0,0,1,24-24h80a23.93,23.93,0,0,1,24,24h0v40"
                                                        style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                    </path>
                                                    <line
                                                        style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                        x1="256" x2="256" y1="176" y2="400"></line>
                                                    <line
                                                        style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                        x1="184" x2="192" y1="176" y2="400"></line>
                                                    <line
                                                        style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                        x1="328" x2="320" y1="176" y2="400"></line>
                                                </svg>
                                            </span>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                
                                <form action="<?php echo e(route('kunjungan_rumah_bayi.show', ['id' => $dataKK->id])); ?>"
                                    method="GET" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <button class="custom-btn btn-2">
                                        Detail lengkap
                                    </button>
                                </form>
                                
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Apakah Kamu Yakin?',
                        text: "Menghapus Data!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Apakah Kamu Yakin?',
                        text: "Menghapus Data!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
        document.querySelectorAll('.status-box').forEach(function(td) {
            if (td.textContent === "Tidak") {
                td.style.backgroundColor = 'red';
            } else if (td.textContent === "Ya") {
                td.style.backgroundColor = 'blue';
            } else if (td.textContent === "Selesai") {
                td.style.backgroundColor = 'green';
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/kunjungan_rumah_bayi/list.blade.php ENDPATH**/ ?>