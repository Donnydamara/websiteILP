<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>7. Checklist Kunjungan Rumah - Usia Sekolah / Remaja</title>
    <style>
        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px 12px;
            text-align: center;
            border: 1px solid #ccc;
            font-size: 45%
        }

        th {
            background-color: #f2f2f2;
        }

        h3 {
            text-align: center;
        }

        /* Media query untuk menyesuaikan ukuran teks */
    </style>
</head>

<body>
    <h3>7. Checklist Kunjungan Rumah - Usia Sekolah / Remaja</h3>
    <table>

        <tbody aria-colspan="14">
            <?php if($kunjunganusiasekolah->isNotEmpty()): ?>
                <tr>
                    <th colspan="3">Nama</th>
                    <td colspan="11"><?php echo e($kunjunganusiasekolah[0]->nama); ?></td>
                </tr>
                <tr>
                    <th colspan="3">Tempat / Tanggal Lahir</th>
                    <td colspan="11"><?php echo e($kunjunganusiasekolah[0]->tmp_lahir); ?> /
                        <?php echo e($kunjunganusiasekolah[0]->tgl_lahir); ?></td>
                </tr>
                <tr>
                    <th colspan="3">Jenis Kelamin</th>
                    <td colspan="11"><?php echo e($kunjunganusiasekolah[0]->gender); ?></td>
                </tr>
            <?php endif; ?>
            <tr>
                <th scope="row" colspan="1" rowspan="2">Kunjungan</th>
                <th scope="row" colspan="1" rowspan="2">Tanggal</th>
                <th scope="row" colspan="1" rowspan="2">Pemantauan Suhu</th>
                <th scope="row" colspan="1" rowspan="2">Tanggal Terakhir Menimbang Dan Mengukur</th>
                <th scope="row" colspan="1" rowspan="2">Isi Piringku Usia Sekolah/Remaja</th>
                <th scope="row" colspan="1" rowspan="2">Hasil Penimbangan Dan Pengukuran</th>
                <th scope="row" colspan="3" rowspan="1">Remaja Putri</th>
                <th scope="row" colspan="1" rowspan="2">Merokok</th>
                <th scope="row" colspan="2" rowspan="1">Remaja >15 Tahun Pemeriksaan PTM*) Satu Tahun
                    Terakhir</th>
                <th scope="row" colspan="1" rowspan="2">Melakukan Skrining Kesehatan Jiwa</th>
                <th scope="row" colspan="1" rowspan="2">Pemberian Edukasi / Kunjungan Nakes</th>
            </tr>
            <tr>

                <th colspan="1">Ada TTD</th>
                <th colspan="1">Minum TTD Minggu Ini / Dalam 7 Hari terakhir</th>
                <th colspan="1">Pemeriksaan Anemia (Skrining Hb) Satu Tahun Terakhir</th>

                <th colspan="1">Gula Darah</th>
                <th colspan="1">Tekanan Darah</th>
            </tr>

            <?php $__currentLoopData = $kunjunganusiasekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>
                    <td rowspan="3"><?php echo e($member->kunjungan); ?></td>
                    <td rowspan="3"><?php echo e($member->tgl_kunjungan); ?></td>
                    <td rowspan="3"><?php echo e($member->suhu_tubuh); ?></td>
                    <td rowspan="1">Tanggal <br> <?php echo e($member->tgl_timbang_ukur); ?></td>
                    <td rowspan="3"><?php echo e($member->porsi); ?></td>
                    <td rowspan="1">BB <br> <?php echo e($member->bb_timbang_ukur); ?></td>
                    <td rowspan="3">
                        <?php if($member->gender == 'Wanita'): ?>
                            <?php echo e($member->ada_ttd_putri); ?>

                        <?php endif; ?>
                    </td>
                    <td rowspan="3">
                        <?php if($member->gender == 'Wanita'): ?>
                            <?php echo e($member->minum_ttd_putri); ?>

                        <?php endif; ?>
                    </td>
                    <td rowspan="1">
                        Tanggal
                        <br>
                        <?php if($member->gender == 'Wanita'): ?>
                            <?php echo e($member->tgl_skrining_hb_putri); ?>

                        <?php endif; ?>
                    </td>
                    <td rowspan="3"><?php echo e($member->merokok); ?></td>
                    <td rowspan="1">Tanggal <br><?php echo e($member->tgl_gula_darah_periksi_ptm); ?></td>
                    <td rowspan="1">Tanggal <br><?php echo e($member->tgl_tekanan_darah_periksi_ptm); ?></td>
                    <td rowspan="1">Tanggal <br><?php echo e($member->tgl_skrining); ?></td>
                    <td rowspan="3"><?php echo e($member->edukasi); ?></td>
                </tr>
                
                <tr>
                    <td scope="row" colspan="1" rowspan="1">Tempat <br> <?php echo e($member->tmp_timbang_ukur); ?></td>
                    <td scope="row" colspan="1" rowspan="1">TB <br> <?php echo e($member->tb_timbang_ukur); ?></td>

                    <td scope="row" colspan="1" rowspan="1">Tempat <br>
                        <?php if($member->gender == 'Wanita'): ?>
                            <?php echo e($member->tmp_skrining_hb_putri); ?>

                        <?php endif; ?>
                    </td>
                    <td scope="row" colspan="1" rowspan="1">Tempat <br>
                        <?php echo e($member->tmp_gula_darah_periksi_ptm); ?></td>
                    <td scope="row" colspan="1" rowspan="1">Tempat <br>
                        <?php echo e($member->tmp_tekanan_darah_periksi_ptm); ?></td>
                    <td scope="row" colspan="1" rowspan="1">Tempat <br>
                        <?php echo e($member->tmp_skrining); ?></td>

                </tr>
                
                <tr>
                    <td scope="row" colspan="1" rowspan="1"> <br>

                        <?php echo e($member->hasil_periksa_satu_tahun_terakhir_ptd); ?></td>
                    <td scope="row" colspan="1" rowspan="1">LP <br> <?php echo e($member->lp_timbang_ukur); ?></td>


                    <td scope="row" colspan="1" rowspan="1">Hasil <br>
                        <?php if($member->gender == 'Wanita'): ?>
                            <?php echo e($member->hasil_skrining_hb_putri); ?>

                        <?php endif; ?>
                    </td>

                    <td scope="row" colspan="1" rowspan="1">Hasil <br>
                        <?php echo e($member->hasil_gula_darah_periksi_ptm); ?></td>
                    <td scope="row" colspan="1" rowspan="1">Hasil <br>
                        <?php echo e($member->hasil_tekanan_darah_periksi_ptm); ?></td>
                    <td scope="row" colspan="1" rowspan="1">Petugas <br>
                        <?php echo e($member->petugas_skrining); ?></td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/kunjungan_usia_sekolah/pdf.blade.php ENDPATH**/ ?>