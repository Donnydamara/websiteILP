<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Kunjungan Tindak Lanjut</title>
    <style>
        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: center;
            border: 1px solid #ccc;
            font-size: 14px;
        }

        th {
            background-color: #f2f2f2;
        }

        h3 {
            text-align: center;
            margin-top: 20px;
            font-size: 24px;
        }

        .page-break {
            page-break-before: always;
        }
    </style>
</head>

<body>
    <h3>Data Kunjungan Tindak Lanjut</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Posyandu</th>
                <th>Waktu</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>No Telepon</th>
                <th>Masalah Kesehatan</th>
                <th>Tindak Lanjut</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tindakLanjutKunjungans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tindakLanjutKunjungan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->posyandu); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->waktu); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->nama); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->nik); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->tgl_lahir); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->alamat); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->no_telepon); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->masalah_kesehatan_yang_ditemukan); ?></td>
                    <td><?php echo e($tindakLanjutKunjungan->tindak_lanjut); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/tindak_lanjut_kunjungan/all_pdf.blade.php ENDPATH**/ ?>