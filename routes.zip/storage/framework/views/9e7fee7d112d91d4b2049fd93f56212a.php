

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Data Keluarga Dan Anggota Keluarga')); ?></h1>

    <!-- Main Content goes here -->
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>
    <div class="card">
        <div class="progress">
            <div class="progress-bar" role="progressbar" style="width: 20%;" aria-valuenow="25" aria-valuemin="0"
                aria-valuemax="100">20%</div>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('datakk.storekkpgs')); ?>" method="post" id="modal-save-form">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <div class="form-group">
                                <label for="kk">Kartu Keluarga</label>
                                <input type="number" class="form-control <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kk"
                                    id="kk" placeholder="Kartu Keluarga" autocomplete="off"
                                    value="<?php echo e(session('kk')); ?>" required>
                                <!-- Populate KK from session -->
                                <?php $__errorArgs = ['kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="nama">Nama Lengkap</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama"
                                id="nama" placeholder="Nama Lengkap" autocomplete="off"
                                value="<?php echo e(session('kepala_kk')); ?>" required>
                            <!-- Populate Kepala Keluarga from session -->
                            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="number" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik"
                                id="nik" placeholder="NIK" autocomplete="off" value="<?php echo e(old('nik')); ?>" required>
                            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="tgl_lahir">Tanggal Lahir</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="tgl_lahir" id="tgl_lahir" autocomplete="off" value="<?php echo e(old('tgl_lahir')); ?>" required>
                            <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="gender">Jenis Kelamin</label>
                            <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gender" id="gender"
                                required>
                                <option value="">-- Select Gender --</option>
                                <option value="Laki-laki" <?php echo e(old('gender') == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki
                                </option>
                                <option value="Perempuan" <?php echo e(old('gender') == 'Perempuan' ? 'selected' : ''); ?>>Perempuan
                                </option>
                            </select>
                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-4">

                        <div class="form-group">
                            <label for="hubungan_keluarga">Hubungan Keluarga</label>
                            <select class="form-control <?php $__errorArgs = ['hubungan_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="hubungan_keluarga" id="hubungan_keluarga" required>
                                <option value="">-- Pilih Hubungan Keluarga --</option>
                                <option value="Kepala Keluarga"
                                    <?php echo e(old('hubungan_keluarga') == 'Kepala Keluarga' ? 'selected' : ''); ?>>Kepala
                                    Kelarga
                                </option>
                                <option value="Istri" <?php echo e(old('hubungan_keluarga') == 'Istri' ? 'selected' : ''); ?>>Istri
                                </option>
                                <option value="Suami" <?php echo e(old('hubungan_keluarga') == 'Suami' ? 'selected' : ''); ?>>Suami
                                </option>
                                <option value="Anak" <?php echo e(old('hubungan_keluarga') == 'Anak' ? 'selected' : ''); ?>>Anak
                                </option>
                                <option value="Menantu" <?php echo e(old('hubungan_keluarga') == 'Menantu' ? 'selected' : ''); ?>>
                                    Menantu
                                </option>
                                <option value="Cucu" <?php echo e(old('hubungan_keluarga') == 'Cucu' ? 'selected' : ''); ?>>Cucu
                                </option>
                                <option value="Orang Tua" <?php echo e(old('hubungan_keluarga') == 'Orang Tua' ? 'selected' : ''); ?>>
                                    Orang Tua
                                </option>
                                <option value="Famili Lain"
                                    <?php echo e(old('hubungan_keluarga') == 'Famili Lain' ? 'selected' : ''); ?>>
                                    Famili Lain</option>
                                <option value="Pembantu/ Asisten/ Pekerja Lain"
                                    <?php echo e(old('hubungan_keluarga') == 'Pembantu/ Asisten/ Pekerja Lain' ? 'selected' : ''); ?>>
                                    Pembantu/
                                    Asisten/ Pekerja Lain</option>
                                <option value="Lainnya" <?php echo e(old('hubungan_keluarga') == 'Lainnya' ? 'selected' : ''); ?>>
                                    Lainnya
                                </option>
                            </select>
                            <?php $__errorArgs = ['hubungan_keluarga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="status_perkawinan">Status Perkawinan</label>
                            <select class="form-control <?php $__errorArgs = ['status_perkawinan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="status_perkawinan" id="status_perkawinan" required>
                                <option value="">-- Pilih Status Perkawinan --</option>
                                <option value="kawin" <?php echo e(old('status_perkawinan') == 'kawin' ? 'selected' : ''); ?>>Kawin
                                </option>
                                <option value="belum_kawin"
                                    <?php echo e(old('status_perkawinan') == 'belum_kawin' ? 'selected' : ''); ?>>Belum
                                    Kawin</option>
                                <option value="cerai_hidup"
                                    <?php echo e(old('status_perkawinan') == 'cerai_hidup' ? 'selected' : ''); ?>>Cerai
                                    Hidup</option>
                                <option value="cerai_mati"
                                    <?php echo e(old('status_perkawinan') == 'cerai_mati' ? 'selected' : ''); ?>>Cerai
                                    Mati</option>
                            </select>
                            <?php $__errorArgs = ['status_perkawinan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="pendidikan_terakhir">Pendidikan Terakhir</label>
                            <select class="form-control <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="pendidikan_terakhir" id="pendidikan_terakhir" required>
                                <option value="">-- Pilih Pendidikan Terakhir --</option>
                                <option value="s1_s2_s3" <?php echo e(old('pendidikan_terakhir') == 's1_s2_s3' ? 'selected' : ''); ?>>
                                    S1 / S2 /
                                    S3 (PT)</option>
                                <option value="d1_d2_d3" <?php echo e(old('pendidikan_terakhir') == 'd1_d2_d3' ? 'selected' : ''); ?>>
                                    D1 / D2 /
                                    D3</option>
                                <option value="sma" <?php echo e(old('pendidikan_terakhir') == 'sma' ? 'selected' : ''); ?>>SMA
                                    atau
                                    sederajat</option>
                                <option value="smp" <?php echo e(old('pendidikan_terakhir') == 'smp' ? 'selected' : ''); ?>>SMP
                                    atau
                                    sederajat</option>
                                <option value="sd" <?php echo e(old('pendidikan_terakhir') == 'sd' ? 'selected' : ''); ?>>SD atau
                                    sederajat
                                </option>
                                <option value="tidak_pernah_sekolah"
                                    <?php echo e(old('pendidikan_terakhir') == 'tidak_pernah_sekolah' ? 'selected' : ''); ?>>Tidak
                                    pernah
                                    sekolah</option>
                            </select>
                            <?php $__errorArgs = ['pendidikan_terakhir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="pekerjaan">Pekerjaan</label>
                            <select class="form-control <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pekerjaan"
                                id="pekerjaan" required>
                                <option value="">-- Pilih Pekerjaan --</option>
                                <option value="tidak_bekerja" <?php echo e(old('pekerjaan') == 'tidak_bekerja' ? 'selected' : ''); ?>>
                                    Tidak
                                    Bekerja</option>
                                <option value="pelajar_mahasiswa"
                                    <?php echo e(old('pekerjaan') == 'pelajar_mahasiswa' ? 'selected' : ''); ?>>
                                    Pelajar / Mahasiswa</option>
                                <option value="pns_tni_polri_bumn_bumd"
                                    <?php echo e(old('pekerjaan') == 'pns_tni_polri_bumn_bumd' ? 'selected' : ''); ?>>PNS / TNI-POLRI /
                                    BUMN /
                                    BUMD</option>
                                <option value="pegawai_swasta"
                                    <?php echo e(old('pekerjaan') == 'pegawai_swasta' ? 'selected' : ''); ?>>
                                    Pegawai Swasta</option>
                                <option value="wiraswasta" <?php echo e(old('pekerjaan') == 'wiraswasta' ? 'selected' : ''); ?>>
                                    Wiraswasta
                                </option>
                                <option value="petani_nelayan"
                                    <?php echo e(old('pekerjaan') == 'petani_nelayan' ? 'selected' : ''); ?>>Petani
                                    / Nelayan</option>
                                <option value="lainnya" <?php echo e(old('pekerjaan') == 'lainnya' ? 'selected' : ''); ?>>Lainnya
                                </option>
                            </select>
                            <?php $__errorArgs = ['pekerjaan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="kelompok_sasaran">Kelompok Sasaran</label>
                            <select class="form-control <?php $__errorArgs = ['kelompok_sasaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="kelompok_sasaran" id="kelompok_sasaran" required>
                                <option value="">-- Pilih Kelompok Sasaran --</option>
                                <option value="Ibu Hamil" <?php echo e(old('kelompok_sasaran') == 'Ibu Hamil' ? 'selected' : ''); ?>>
                                    Ibu Hamil
                                </option>
                                <option value="Ibu Bersalin dan Lifas"
                                    <?php echo e(old('kelompok_sasaran') == 'Ibu Bersalin dan Lifas' ? 'selected' : ''); ?>>Ibu
                                    Bersalin dan Lifas</option>
                                <option value="Bayi Balita (0 - 6 tahun)"
                                    <?php echo e(old('kelompok_sasaran') == 'Bayi Balita (0 - 6 tahun)' ? 'selected' : ''); ?>>Bayi
                                    Balita (0 - 6 tahun)</option>
                                <option value="Bayi, Balita Dan Anak Usia Prasekolah (Usia >6 - 71 Bulan)"
                                    <?php echo e(old('kelompok_sasaran') == 'Bayi, Balita Dan Anak Usia Prasekolah (Usia >6 - 71 Bulan)' ? 'selected' : ''); ?>>
                                    Bayi, Balita Dan Anak Usia Prasekolah (Usia >6 - 71 Bulan)</option>
                                <option value="Usia Sekolah dan Remaja (>6 - <18 tahun)"
                                    <?php echo e(old('kelompok_sasaran') == 'Usia Sekolah dan Remaja (>6 - <18 tahun)' ? 'selected' : ''); ?>>
                                    Usia Sekolah dan Remaja (>6 - <18 tahun)</option>
                                <option value="Usia Dewasa (>18 - 59 tahun)"
                                    <?php echo e(old('kelompok_sasaran') == 'Usia Dewasa (>18 - 59 tahun)' ? 'selected' : ''); ?>>Usia
                                    Dewasa (>18 - 59 tahun)</option>
                                <option value="Usia Lansia (Usia 60 Tahun Keatas)"
                                    <?php echo e(old('kelompok_sasaran') == 'Usia Lansia (Usia 60 Tahun Keatas)' ? 'selected' : ''); ?>>
                                    Usia Lansia (Usia 60 Tahun Keatas)</option>
                            </select>
                            <?php $__errorArgs = ['kelompok_sasaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>



                <button type="submit" class="btn btn-primary" onclick="setAction('save')">Lanjut</button>
                <a href="<?php echo e(route('jadwal.index')); ?>" class="btn btn-default">Selesai</a>
                <!-- Button Tambah Data KK -->
                


                <!-- Input hidden untuk menentukan aksi tombol -->
                <input type="hidden" name="action" id="action" value="">


            </form>
        </div>
    </div>



    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Include SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function setAction(action) {
            // Show SweetAlert2 loading animation
            Swal.fire({
                title: 'Simpan...',
                text: 'Tunggu Data Sedang Di Simpan.',
                imageUrl: 'https://media.tenor.com/y6-Oq1X_9NcAAAAC/loading-loading-gif.gif',
                imageWidth: 100,
                imageHeight: 100,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            // Submit the form after showing the loading animation
            document.getElementById('modal-save-form').submit();
        }

        function setAction(action) {
            document.getElementById('action').value = action;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/pendataan_kk/create.blade.php ENDPATH**/ ?>