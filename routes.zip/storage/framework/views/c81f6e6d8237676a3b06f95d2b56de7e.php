<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5. Checklist Kunjungan - Bayi, Balita Dan Anak Usia Prasekolah</title>
    <style>
        table {
            width: 100%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 5px 5px;
            text-align: center;
            border: 1px solid #ccc;
            font-size: 45%
        }

        th {
            background-color: #f2f2f2;
        }

        h3 {
            text-align: center;
        }

        .page-break {
            page-break-before: always;
        }

        /* Media query untuk menyesuaikan ukuran teks */
    </style>
</head>

<body>
    <h3>5. Checklist Kunjungan - Bayi, Balita Dan Anak Usia Prasekolah</h3>
    <table>

        <tbody aria-colspan="17">
            <?php if($kunjunganbayibalitaPrasekolah->isNotEmpty()): ?>
                <tr>
                    <th colspan="3">Nama</th>
                    <td colspan="23"><?php echo e($kunjunganbayibalitaPrasekolah[0]->nama); ?></td>
                </tr>
                <tr>
                    <th colspan="3">Tempat / Tanggal Lahir</th>
                    <td colspan="23"><?php echo e($kunjunganbayibalitaPrasekolah[0]->tmp_lahir); ?> /
                        <?php echo e($kunjunganbayibalitaPrasekolah[0]->tgl_lahir); ?></td>
                </tr>
                <tr>
                    <th colspan="3">Jenis Kelamin</th>
                    <td colspan="23"><?php echo e($kunjunganbayibalitaPrasekolah[0]->gender); ?></td>
                </tr>
            <?php endif; ?>
            
            <tr>
                <th scope="row" colspan="1" rowspan="2">Kunjungan</th>
                <th scope="row" colspan="1" rowspan="2">Tanggal</th>
                <th scope="row" colspan="1" rowspan="2">Pemantauan Suhu Tubuh</th>
                <th scope="row" colspan="1" rowspan="2">Ada Buku KIA</th>
                <th scope="row" colspan="1" rowspan="2">Tanggal Terakhir Di Timbang</th>
                <th scope="row" colspan="1" rowspan="2">Hasil Penimbangan Dan Pengukuran</th>
                <th scope="row" colspan="9" rowspan="1">Imunisasi</th>
                <th scope="row" colspan="5" rowspan="1">Pemberian
                    Makanan Pendamping ASI Kaya Protein Hewani</th>
                <th scope="row" colspan="2" rowspan="1">Obat Cacing</th>
                <th scope="row" colspan="2" rowspan="1">Kapsul Vitamin A</th>
                <th scope="row" colspan="2" rowspan="1">Makanan Tambahan Pangan Lokal Bagi Balita Dengan
                    Masalah Gizi</th>
                <th scope="row" colspan="1" rowspan="2">Pemberian Edukasi/ Kunjungan Nakes</th>


            </tr>
            
            <tr>
                <th>Usia <br> 0 <br>Bulan</th>
                <th>Usia <br> 1 <br>Bulan</th>
                <th>Usia <br> 2 <br>Bulan</th>
                <th>Usia <br> 3 <br>Bulan</th>
                <th>Usia <br> 4 <br>Bulan</th>
                <th>Usia <br> 9 <br>Bulan</th>
                <th>Usia <br> 10 <br>Bulan</th>
                <th>Usia <br> 12 <br>Bulan</th>
                <th>Usia <br> 18 <br>Bulan</th>
                <th>Makanan Pokok<br> (Beras/<br>Kentang/<br>Jagung)</th>
                <th>Makanan Sumber <br> Proteiin Hewani<br>
                    (Telur/<br>Ikan/<br>Ayam/<br>Daging/<br>Udang/<br>Hati/<br>Susu <br>Dan Produk<br> Olahan)</th>
                <th>Makanan Sumber<br> Protein Nabati<br> (Tahu/<br>Tempe/<br>Kacang <br>Hijau/<br>Kacang <br>Polong)
                </th>
                <th>Sumber Lemak (Minyak /Santan)</th>
                <th>Buah Dan Sayur</th>
                <th>Ada</th>
                <th>Waktu Makan</th>
                <th>Jenis
                    Kunjungan</th>
                <th>Jenis
                    Kunjungan2</th>

                <th>Ada</th>
                <th>Kepatuhan Konsumsi</th>

            </tr>
            
            <?php $__currentLoopData = $kunjunganbayibalitaPrasekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td rowspan="4"><?php echo e($member->kunjungan); ?></td>
                    <td rowspan="4"><?php echo e($member->tgl_kunjungan); ?></td>
                    <td rowspan="4"><?php echo e($member->suhu_tubuh); ?></td>
                    <td rowspan="4"><?php echo e($member->buku_kia); ?></td>
                    <td rowspan="1">Tanggal <br> <?php echo e($member->tgl_timbang_ukur); ?></td>
                    <td rowspan="1">BB <br> <?php echo e($member->bb_hasil_timbang_ukur); ?></td>
                    <td rowspan="1">Hepatitis B <br> (<24 Jam) <br> <?php echo e($member->hepatitis_b_0bulan); ?></td>
                    <td rowspan="1">BCG <br> <?php echo e($member->bcg_1bulan); ?></td>
                    <td rowspan="1">DPT-HB-Hib

                        <br> <?php echo e($member->dpt_hb_hib_1_2bulan); ?>

                    </td>
                    <td rowspan="1">DPT-HB-Hib

                        <br> <?php echo e($member->dpt_hb_hib_2_3bulan); ?>

                    </td>
                    <td rowspan="1">DPT-HB-Hib

                        <br> <?php echo e($member->dpt_hb_hib_3_4bulan); ?>

                    </td>
                    <td rowspan="2">Campak
                        Rubella

                        <br> <?php echo e($member->campak_rubelia_9bulan); ?>

                    </td>
                    <td rowspan="4">Jepanese encephalitis (JE)
                        <br> <?php echo e($member->je_10bulan); ?>

                    </td>
                    <td rowspan="4">PCV3
                        <br> <?php echo e($member->pv_3_12bulan); ?>

                    </td>
                    <td rowspan="2">DPT-HB-hib 1 Lanjutan

                        <br> <?php echo e($member->dpt_lanjut_1_18bulan); ?>

                    </td>
                    <td rowspan="4"><?php echo e($member->makanan_pokok); ?></td>
                    <td rowspan="4"><?php echo e($member->makanan_protein_hewan); ?></td>
                    <td rowspan="4"><?php echo e($member->makanan_protein_nabati); ?></td>
                    <td rowspan="4"><?php echo e($member->makanan_lemak); ?></td>
                    <td rowspan="4"><?php echo e($member->sayur_buah); ?></td>
                    <td rowspan="4"><?php echo e($member->oc_ada); ?></td>
                    <td rowspan="4">Tanggal <br><?php echo e($member->oc_tgl); ?></td>
                    
                    <td scope="row" colspan="1" rowspan="2">Mulai <br>
                        <?php if($member->kv_jenis == 'Usia 6 - 11 Bulan (Kapsul Biru)'): ?>
                            <?php echo e($member->tgl_kv_mulai); ?>

                        <?php endif; ?>
                    </td>


                    <td scope="row" colspan="1" rowspan="2">Mulai <br>
                        <?php if($member->kv_jenis == 'Usia >11 Bulan (Kapsul Merah)'): ?>
                            <?php echo e($member->tgl_kv_mulai); ?>

                        <?php endif; ?>
                    </td>
                    <td rowspan="4"><?php echo e($member->makan_tambah_ada); ?></td>
                    <td rowspan="4"> <?php echo e($member->makan_tambah_kepatuhan); ?></td>
                    <td rowspan="4"> <?php echo e($member->edukasi); ?></td>


                </tr>
                
                <tr>
                    <td scope="row" colspan="1" rowspan="1">Tempat <br> <?php echo e($member->tempat_timbang_ukur); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">PB/TB <br> <?php echo e($member->pb_tb_hasil_timbang_ukur); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">BCG <br> <?php echo e($member->bcg_0bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">Polio Tetes
                        1 <br> <?php echo e($member->polio_1bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">Polio Tetes
                        <br> <?php echo e($member->polio_2_2bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">Polio Tetes
                        <br> <?php echo e($member->polio_3_3bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">Polio Tetes
                        <br> <?php echo e($member->polio_4_4bulan); ?>

                    </td>


                </tr>
                
                <tr>
                    <td scope="row" colspan="1" rowspan="2">Petugas <br> <?php echo e($member->petugas_timbang_ukur); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="2">LK <br> <?php echo e($member->lk_hasil_timbang_ukur); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="2">Polio Tetes
                        1 <br> <?php echo e($member->polio_0bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="2">
                    </td>
                    <td scope="row" colspan="1" rowspan="1">PCV <br> <?php echo e($member->pcv_1_2bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">PCV <br> <?php echo e($member->pcv_2_3bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">Polio Suntik
                        <br> <?php echo e($member->polio_suntik_4bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="2">Polio Suntik
                        <br> <?php echo e($member->polio_suntik_2_9bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="2">Campak-rubella Lanjutan
                        <br> <?php echo e($member->campak_lanjut_18bulan); ?>

                    </td>

                    <td scope="row" colspan="1" rowspan="2">Selesai <br>
                        <?php if($member->kv_jenis == 'Usia 6 - 11 Bulan (Kapsul Biru)'): ?>
                            <?php echo e($member->tgl_kv_selesai); ?>

                        <?php endif; ?>
                    </td>


                    <td scope="row" colspan="1" rowspan="2">Selesai <br>
                        <?php if($member->kv_jenis == 'Usia >11 Bulan (Kapsul Merah)'): ?>
                            <?php echo e($member->tgl_kv_selesai); ?>

                        <?php endif; ?>
                    </td>


                </tr>
                
                <tr>
                    <td scope="row" colspan="1" rowspan="1">RV <br> <?php echo e($member->rv_1_2bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">RV <br> <?php echo e($member->rv_2_3bulan); ?>

                    </td>
                    <td scope="row" colspan="1" rowspan="1">RV <br> <?php echo e($member->rv_3_4bulan); ?>

                    </td>

                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <div class="page-break"></div>
    <!-- Mulai tabel baru pada halaman kedua -->
    <h3>5. Checklist Kunjungan - Bayi, Balita Dan Anak Usia Prasekolah (Lembar 2)</h3>
    <table>

        <tbody>
            <tr>
                <th scope="row" colspan="1" rowspan="2">Wkatu Kunjungan</th>
                <th scope="row" colspan="1" rowspan="2">Tanggal</th>
                <th scope="row" colspan="8" rowspan="1">Tanda Bahaya Pada Bayi 2 - 60 Bulan</th>
                <th scope="row" colspan="1" rowspan="2">Mengingatkan Periksa Ke Postu/ Fasyankes</th>
                <th scope="row" colspan="1" rowspan="2">Melaporkan Ke Nakes</th>
            </tr>
            <tr>
                <th>Napas</th>
                <th>Batuk</th>
                <th>Diare</th>
                <th>Jumlah Dan Warna Kencing</th>
                <th>Warna Kulit</th>
                <th>Aktifitas</th>
                <th>Hisapan Bayi</th>
                <th>Pemberian Makan</th>
            </tr>
            <?php $__currentLoopData = $kunjunganbayibalitaPrasekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($member->kunjungan); ?></td>
                    <td><?php echo e($member->tgl_kunjungan); ?></td>
                    <td><?php echo e($member->napas); ?></td>
                    <td><?php echo e($member->batuk); ?></td>
                    <td><?php echo e($member->diare); ?></td>
                    <td><?php echo e($member->jmh_warna_kencing); ?></td>
                    <td><?php echo e($member->warna_kulit); ?></td>
                    <td><?php echo e($member->aktifitas); ?></td>
                    <td><?php echo e($member->hisapan_bayi); ?></td>
                    <td><?php echo e($member->pemberian_makan); ?></td>
                    <td><?php echo e($member->pengingat_periksa_postu); ?></td>
                    <td><?php echo e($member->lapor_nakes); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\example-app\resources\views/kunjungan_bayi_balita_prasekolah/pdf.blade.php ENDPATH**/ ?>