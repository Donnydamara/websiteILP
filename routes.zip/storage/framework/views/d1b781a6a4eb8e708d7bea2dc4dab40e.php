

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e($title ?? __('Detail Data Keluarga Dan Anggota Keluarga')); ?></h1>

    <!-- Main Content goes here -->

    
    <div class="row mb-3">
        <div class="col text-center">
            <!-- Tombol Tambah Data (untuk role 'kader') -->
            <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                <button class="btn btn-primary mb-2"
                    onclick="window.location.href='<?php echo e(route('pendataan_kk.createdetail', ['id' => $dataKK->id])); ?>'">
                    Tambah Data
                </button>
            <?php endif; ?>

            <!-- Tombol Kembali (untuk role 'admin') -->
            <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                <form action="<?php echo e(route('datakk.index')); ?>" method="GET" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-secondary mb-2">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </button>
                </form>
            <?php endif; ?>

            <!-- Tombol Download PDF -->
            <a href="<?php echo e(route('pendataan.kk.pdf', ['kk' => $dataKK->kk])); ?>" target="_blank" class="btn btn-info mb-2">
                <i class="fas fa-file-pdf"></i> Download PDF
            </a>

            <!-- Tombol Export Excel -->
            <form method="GET" action="<?php echo e(route('datakk.show', ['id' => $dataKK->id])); ?>" class="d-inline">
                <button type="submit" class="btn btn-success mb-2" name="export" value="1">
                    <i class="fas fa-file-excel"></i> Export Excel
                </button>
            </form>

            <a href="<?php echo e(route('datakk.index')); ?>" class="btn btn-primary mb-2">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>
    </div>


    


    
    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success',
                    text: '<?php echo e(session('success')); ?>',
                });
            });
        </script>
    <?php endif; ?>
    <div class="table-responsive" style="text-align: center">
        <table class="table table-bordered table-striped" id="dataTable">
            <thead>
                <tr>
                    <th style="text-align: center">No</th>
                    <th style="text-align: center">Kartu Keluarga</th>
                    <th style="text-align: center">Nama</th>
                    <th style="text-align: center">NIK</th>
                    <th style="text-align: center">Jenis Kelamin</th>
                    <th style="text-align: center">Hubungan Keluarga</th>
                    <th style="text-align: center">Kelompok Sasaran</th>
                    <th style="text-align: center">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if($familyMembers->isNotEmpty()): ?>
                    <?php $__currentLoopData = $familyMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($dataKK->kk); ?></td>
                            <td><?php echo e($member->nama); ?></td>
                            <td><?php echo e($member->nik); ?></td>
                            <td><?php echo e($member->gender); ?></td>
                            <td><?php echo e($member->hubungan_keluarga); ?></td>
                            <td><?php echo e($member->kelompok_sasaran); ?></td>
                            <td>
                                <div class="d-flex">
                                    <?php if(Auth::check() && Auth::user()->role == 'kader'): ?>
                                        
                                        <button class="edit"
                                            onclick="window.location.href='<?php echo e(route('pendataan_kk.editdetail', ['id' => $member->id])); ?>'">
                                            Edit
                                            <span></span>
                                        </button>
                                        <form action="<?php echo e(route('datakk.destroy2', ['id' => $member->id])); ?>" method="POST"
                                            onsubmit="">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger hidden">Hapus</button>
                                        </form>
                                        <form action="<?php echo e(route('datakk.destroy2', ['id' => $member->id])); ?>" method="post"
                                            class="delete-form">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="delete">
                                                <span class="delete__text">Hapus</span>
                                                <span class="delete__icon">
                                                    <svg class="svg" height="512" viewBox="0 0 512 512" width="512"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <title></title>
                                                        <path
                                                            d="M112,112l20,320c.95,18.49,14.4,32,32,32H348c17.67,0,30.87-13.51,32-32l20-320"
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                        </path>
                                                        <line
                                                            style="stroke:#fff;stroke-linecap:round;stroke-miterlimit:10;stroke-width:32px"
                                                            x1="80" x2="432" y1="112" y2="112">
                                                        </line>
                                                        <path
                                                            d="M192,112V72h0a23.93,23.93,0,0,1,24-24h80a23.93,23.93,0,0,1,24,24h0v40"
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px">
                                                        </path>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="256" x2="256" y1="176" y2="400">
                                                        </line>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="184" x2="192" y1="176" y2="400">
                                                        </line>
                                                        <line
                                                            style="fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:32px"
                                                            x1="328" x2="320" y1="176" y2="400">
                                                        </line>
                                                    </svg>
                                                </span>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <form method="GET" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="custom-btn btn-2" data-toggle="modal"
                                            data-target="#detailModal<?php echo e($member->id); ?>">
                                            Detail
                                        </button>


                                        <!-- Modal -->
                                        <div class="modal fade" id="detailModal<?php echo e($member->id); ?>" tabindex="-1"
                                            role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Detail Anggota
                                                            Keluarga
                                                        </h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <!-- Card View Content -->
                                                        <div class="card">
                                                            <div class="card-body">
                                                                <!-- Table Content -->
                                                                <table class="table table-bordered">
                                                                    <tbody>
                                                                        <tr>
                                                                            <th scope="row">No Kartu Keluarga</th>
                                                                            <td><?php echo e($member->kk); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Nama</th>
                                                                            <td><?php echo e($member->nama); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">NIK</th>
                                                                            <td><?php echo e($member->nik); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Gender</th>
                                                                            <td><?php echo e($member->gender); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Hubungan Keluarga</th>
                                                                            <td><?php echo e($member->hubungan_keluarga); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Status Perkawinan</th>
                                                                            <td><?php echo e($member->status_perkawinan); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Pendidikan Terakhir</th>
                                                                            <td><?php echo e($member->pendidikan_terakhir); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Pekerjaan</th>
                                                                            <td><?php echo e($member->pekerjaan); ?></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <th scope="row">Kelompok Sasaran</th>
                                                                            <td><?php echo e($member->kelompok_sasaran); ?></td>
                                                                        </tr>

                                                                        <!-- Add more information fields here -->
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                        <!-- End of Modal -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="11">No family members found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <style>
        .hidden {
            display: none;
        }
    </style>
    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Apakah Kamu Yakin?',
                        text: "Menghapus Data!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deleteForms = document.querySelectorAll('.delete-form');
            deleteForms.forEach(form => {
                form.addEventListener('submit', function(event) {
                    event.preventDefault();
                    const formElement = this;
                    Swal.fire({
                        title: 'Apakah Kamu Yakin?',
                        text: "Menghapus Data!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            formElement.submit();
                        }
                    });
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\example-app\resources\views/pendataan_kk/detail.blade.php ENDPATH**/ ?>